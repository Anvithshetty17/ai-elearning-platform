from flask import Flask, request, jsonify
from flask_cors import CORS
import os
import logging
from datetime import datetime
import asyncio
from concurrent.futures import ThreadPoolExecutor
import traceback

# Import service modules
from services.tts_service import TTSService
from services.video_service import VideoService
from services.transcript_service import TranscriptService
from services.notification_service import NotificationService

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)
CORS(app)

# Configuration
app.config['MAX_CONTENT_LENGTH'] = int(os.getenv('MAX_FILE_SIZE', 50 * 1024 * 1024))  # 50MB
app.config['UPLOAD_FOLDER'] = os.getenv('UPLOAD_FOLDER', './temp')

# Initialize services
tts_service = TTSService()
video_service = VideoService()
transcript_service = TranscriptService()
notification_service = NotificationService()

# Thread pool for async processing
executor = ThreadPoolExecutor(max_workers=4)

# Ensure upload directory exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs('./models', exist_ok=True)
os.makedirs('./output', exist_ok=True)

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.utcnow().isoformat(),
        'services': {
            'tts': tts_service.is_available(),
            'video': video_service.is_available(),
            'transcript': transcript_service.is_available()
        },
        'version': '1.0.0'
    })

@app.route('/', methods=['GET'])
def root():
    """Root endpoint with API information"""
    return jsonify({
        'message': 'AI E-Learning ML Services API',
        'version': '1.0.0',
        'status': 'active',
        'endpoints': {
            'health': '/health',
            'tts': '/tts',
            'generate_video': '/generate-video',
            'transcript': '/transcript',
            'process_lecture': '/process-lecture'
        },
        'timestamp': datetime.utcnow().isoformat()
    })

@app.route('/tts', methods=['POST'])
def text_to_speech():
    """Convert text to speech"""
    try:
        data = request.get_json()
        
        if not data or 'text' not in data:
            return jsonify({
                'success': False,
                'error': 'Text content is required'
            }), 400

        text = data['text']
        language = data.get('language', 'en')
        voice_settings = data.get('voice_settings', {})
        
        logger.info(f"TTS request: {len(text)} characters, language: {language}")
        
        # Generate speech
        result = tts_service.generate_speech(
            text=text,
            language=language,
            speed=voice_settings.get('speed', 1.0),
            pitch=voice_settings.get('pitch', 1.0),
            voice=voice_settings.get('voice', 'default')
        )
        
        if result['success']:
            logger.info(f"TTS completed: {result['audio_path']}")
            return jsonify({
                'success': True,
                'audio_path': result['audio_path'],
                'duration': result['duration'],
                'message': 'Speech generated successfully'
            })
        else:
            logger.error(f"TTS failed: {result['error']}")
            return jsonify({
                'success': False,
                'error': result['error']
            }), 500
            
    except Exception as e:
        logger.error(f"TTS endpoint error: {str(e)}")
        logger.error(traceback.format_exc())
        return jsonify({
            'success': False,
            'error': 'Failed to generate speech'
        }), 500

@app.route('/generate-video', methods=['POST'])
def generate_video():
    """Generate video from audio and settings"""
    try:
        data = request.get_json()
        
        required_fields = ['audio_path']
        if not data or not all(field in data for field in required_fields):
            return jsonify({
                'success': False,
                'error': f'Required fields: {required_fields}'
            }), 400

        audio_path = data['audio_path']
        video_settings = data.get('video_settings', {})
        
        logger.info(f"Video generation request: {audio_path}")
        
        # Generate video
        result = video_service.generate_video(
            audio_path=audio_path,
            quality=video_settings.get('quality', '720p'),
            avatar_type=video_settings.get('avatar_type', 'static'),
            background_type=video_settings.get('background_type', 'simple'),
            title=data.get('title', 'AI Generated Lecture')
        )
        
        if result['success']:
            logger.info(f"Video generated: {result['video_path']}")
            return jsonify({
                'success': True,
                'video_path': result['video_path'],
                'thumbnail_path': result.get('thumbnail_path'),
                'duration': result['duration'],
                'message': 'Video generated successfully'
            })
        else:
            logger.error(f"Video generation failed: {result['error']}")
            return jsonify({
                'success': False,
                'error': result['error']
            }), 500
            
    except Exception as e:
        logger.error(f"Video generation endpoint error: {str(e)}")
        logger.error(traceback.format_exc())
        return jsonify({
            'success': False,
            'error': 'Failed to generate video'
        }), 500

@app.route('/transcript', methods=['POST'])
def generate_transcript():
    """Generate transcript from audio"""
    try:
        data = request.get_json()
        
        if not data or 'audio_path' not in data:
            return jsonify({
                'success': False,
                'error': 'Audio path is required'
            }), 400

        audio_path = data['audio_path']
        language = data.get('language', 'en')
        
        logger.info(f"Transcript request: {audio_path}, language: {language}")
        
        # Generate transcript
        result = transcript_service.generate_transcript(
            audio_path=audio_path,
            language=language
        )
        
        if result['success']:
            logger.info(f"Transcript generated: {len(result['transcript'])} characters")
            return jsonify({
                'success': True,
                'transcript': result['transcript'],
                'transcript_path': result.get('transcript_path'),
                'message': 'Transcript generated successfully'
            })
        else:
            logger.error(f"Transcript generation failed: {result['error']}")
            return jsonify({
                'success': False,
                'error': result['error']
            }), 500
            
    except Exception as e:
        logger.error(f"Transcript endpoint error: {str(e)}")
        logger.error(traceback.format_exc())
        return jsonify({
            'success': False,
            'error': 'Failed to generate transcript'
        }), 500

@app.route('/process-lecture', methods=['POST'])
def process_lecture():
    """Process complete lecture (TTS + Video + Transcript)"""
    try:
        data = request.get_json()
        
        required_fields = ['lectureId', 'textContent']
        if not data or not all(field in data for field in required_fields):
            return jsonify({
                'success': False,
                'error': f'Required fields: {required_fields}'
            }), 400

        lecture_id = data['lectureId']
        text_content = data['textContent']
        language = data.get('language', 'en')
        voice_settings = data.get('voiceSettings', {})
        video_settings = data.get('videoSettings', {})
        
        logger.info(f"Processing lecture {lecture_id}: {len(text_content)} characters")
        
        # Start async processing
        future = executor.submit(
            process_lecture_async,
            lecture_id,
            text_content,
            language,
            voice_settings,
            video_settings
        )
        
        return jsonify({
            'success': True,
            'message': 'Lecture processing started',
            'lectureId': lecture_id,
            'status': 'processing'
        })
        
    except Exception as e:
        logger.error(f"Process lecture endpoint error: {str(e)}")
        logger.error(traceback.format_exc())
        return jsonify({
            'success': False,
            'error': 'Failed to start lecture processing'
        }), 500

def process_lecture_async(lecture_id, text_content, language, voice_settings, video_settings):
    """Async lecture processing pipeline"""
    try:
        logger.info(f"Starting async processing for lecture {lecture_id}")
        
        # Update status: Text Analysis
        notification_service.update_lecture_status(
            lecture_id, 'processing', 'text-analysis', 10
        )
        
        # Step 1: Generate Speech
        logger.info(f"Generating speech for lecture {lecture_id}")
        tts_result = tts_service.generate_speech(
            text=text_content,
            language=language,
            speed=voice_settings.get('speed', 1.0),
            pitch=voice_settings.get('pitch', 1.0),
            voice=voice_settings.get('voice', 'default')
        )
        
        if not tts_result['success']:
            raise Exception(f"TTS failed: {tts_result['error']}")
        
        # Update status: TTS Completed
        notification_service.update_lecture_status(
            lecture_id, 'processing', 'tts-conversion', 40
        )
        
        # Step 2: Generate Video
        logger.info(f"Generating video for lecture {lecture_id}")
        video_result = video_service.generate_video(
            audio_path=tts_result['audio_path'],
            quality=video_settings.get('quality', '720p'),
            avatar_type=video_settings.get('avatar_type', 'static'),
            background_type=video_settings.get('background_type', 'simple'),
            title=f"Lecture {lecture_id}"
        )
        
        if not video_result['success']:
            raise Exception(f"Video generation failed: {video_result['error']}")
        
        # Update status: Video Generated
        notification_service.update_lecture_status(
            lecture_id, 'processing', 'video-generation', 70
        )
        
        # Step 3: Generate Transcript
        logger.info(f"Generating transcript for lecture {lecture_id}")
        transcript_result = transcript_service.generate_transcript(
            audio_path=tts_result['audio_path'],
            language=language
        )
        
        if not transcript_result['success']:
            logger.warning(f"Transcript generation failed, continuing: {transcript_result['error']}")
            transcript_result = {'transcript': text_content}  # Fallback to original text
        
        # Update status: Upload
        notification_service.update_lecture_status(
            lecture_id, 'processing', 'upload', 90
        )
        
        # Step 4: Upload files to cloud storage
        logger.info(f"Uploading files for lecture {lecture_id}")
        upload_results = notification_service.upload_lecture_files(
            lecture_id,
            {
                'video_path': video_result['video_path'],
                'audio_path': tts_result['audio_path'],
                'thumbnail_path': video_result.get('thumbnail_path'),
                'transcript': transcript_result['transcript'],
                'duration': video_result['duration']
            }
        )
        
        if not upload_results['success']:
            raise Exception(f"Upload failed: {upload_results['error']}")
        
        # Final status: Completed
        notification_service.update_lecture_status(
            lecture_id, 'completed', 'completed', 100,
            {
                'videoUrl': upload_results['video_url'],
                'audioUrl': upload_results['audio_url'],
                'thumbnailUrl': upload_results.get('thumbnail_url'),
                'transcript': transcript_result['transcript'],
                'duration': video_result['duration']
            }
        )
        
        logger.info(f"Lecture {lecture_id} processing completed successfully")
        
        # Cleanup temporary files
        cleanup_temp_files([
            tts_result['audio_path'],
            video_result['video_path'],
            video_result.get('thumbnail_path'),
            transcript_result.get('transcript_path')
        ])
        
    except Exception as e:
        logger.error(f"Async processing failed for lecture {lecture_id}: {str(e)}")
        logger.error(traceback.format_exc())
        
        # Update status: Failed
        notification_service.update_lecture_status(
            lecture_id, 'failed', 'failed', 0,
            error_message=str(e)
        )

def cleanup_temp_files(file_paths):
    """Clean up temporary files"""
    for file_path in file_paths:
        if file_path and os.path.exists(file_path):
            try:
                os.remove(file_path)
                logger.info(f"Cleaned up: {file_path}")
            except Exception as e:
                logger.error(f"Failed to cleanup {file_path}: {e}")

@app.errorhandler(413)
def too_large(e):
    return jsonify({
        'success': False,
        'error': 'File too large'
    }), 413

@app.errorhandler(404)
def not_found(e):
    return jsonify({
        'success': False,
        'error': 'Endpoint not found'
    }), 404

@app.errorhandler(500)
def server_error(e):
    logger.error(f"Server error: {str(e)}")
    return jsonify({
        'success': False,
        'error': 'Internal server error'
    }), 500

if __name__ == '__main__':
    port = int(os.getenv('FLASK_PORT', 5001))
    debug = os.getenv('FLASK_ENV') == 'development'
    
    logger.info(f"Starting AI ML Services on port {port}")
    logger.info(f"Debug mode: {debug}")
    logger.info(f"Upload folder: {app.config['UPLOAD_FOLDER']}")
    
    app.run(
        host='0.0.0.0',
        port=port,
        debug=debug,
        threaded=True
    )