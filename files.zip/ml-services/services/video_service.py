import os
import tempfile
import logging
from moviepy.editor import *
from PIL import Image, ImageDraw, ImageFont
import numpy as np
import cv2

logger = logging.getLogger(__name__)

class VideoService:
    """Video generation service using MoviePy"""
    
    def __init__(self):
        self.initialize_assets()
    
    def initialize_assets(self):
        """Initialize video generation assets"""
        self.assets_dir = os.path.join(os.path.dirname(__file__), '..', 'assets')
        os.makedirs(self.assets_dir, exist_ok=True)
        
        # Create default avatar if not exists
        self.default_avatar_path = os.path.join(self.assets_dir, 'default_avatar.png')
        if not os.path.exists(self.default_avatar_path):
            self._create_default_avatar()
    
    def is_available(self):
        """Check if video service is available"""
        try:
            # Test basic video operations
            test_clip = ColorClip(size=(100, 100), color=(0, 0, 0), duration=1)
            return True
        except Exception as e:
            logger.error(f"Video service unavailable: {e}")
            return False
    
    def generate_video(self, audio_path, quality='720p', avatar_type='static', 
                      background_type='simple', title='AI Generated Lecture'):
        """
        Generate video from audio and settings
        
        Args:
            audio_path (str): Path to audio file
            quality (str): Video quality ('480p', '720p', '1080p')
            avatar_type (str): Avatar type ('static', 'animated', 'slideshow')
            background_type (str): Background type ('simple', 'gradient', 'custom')
            title (str): Video title
            
        Returns:
            dict: Result with video_path and duration or error
        """
        try:
            logger.info(f"Generating video: {audio_path}, quality: {quality}")
            
            if not os.path.exists(audio_path):
                return {
                    'success': False,
                    'error': 'Audio file not found'
                }
            
            # Load audio
            audio_clip = AudioFileClip(audio_path)
            duration = audio_clip.duration
            
            # Get video dimensions
            width, height = self._get_dimensions(quality)
            
            # Create background
            background_clip = self._create_background(
                width, height, duration, background_type
            )
            
            # Create avatar
            avatar_clip = self._create_avatar(
                width, height, duration, avatar_type
            )
            
            # Create title overlay
            title_clip = self._create_title_overlay(
                width, height, duration, title
            )
            
            # Create waveform visualization (optional)
            waveform_clip = self._create_waveform(
                audio_path, width, height, duration
            )
            
            # Composite video
            final_clip = CompositeVideoClip([
                background_clip,
                avatar_clip.set_position(('center', 'center')),
                waveform_clip.set_position(('center', height * 0.8)),
                title_clip.set_position(('center', height * 0.1))
            ], size=(width, height))
            
            # Set audio
            final_clip = final_clip.set_audio(audio_clip)
            
            # Generate output path
            output_path = os.path.join(
                tempfile.gettempdir(),
                f"video_{int(os.urandom(4).hex(), 16)}.mp4"
            )
            
            # Render video
            logger.info(f"Rendering video to: {output_path}")
            final_clip.write_videofile(
                output_path,
                fps=24,
                codec='libx264',
                audio_codec='aac',
                temp_audiofile='temp-audio.m4a',
                remove_temp=True
            )
            
            # Generate thumbnail
            thumbnail_path = self._generate_thumbnail(final_clip, output_path)
            
            # Cleanup
            final_clip.close()
            audio_clip.close()
            
            logger.info(f"Video generation completed: {output_path}")
            
            return {
                'success': True,
                'video_path': output_path,
                'thumbnail_path': thumbnail_path,
                'duration': duration,
                'resolution': f"{width}x{height}",
                'file_size': os.path.getsize(output_path) if os.path.exists(output_path) else 0
            }
            
        except Exception as e:
            logger.error(f"Video generation error: {str(e)}")
            return {
                'success': False,
                'error': f'Video generation failed: {str(e)}'
            }
    
    def _get_dimensions(self, quality):
        """Get video dimensions based on quality"""
        dimensions = {
            '480p': (854, 480),
            '720p': (1280, 720),
            '1080p': (1920, 1080)
        }
        return dimensions.get(quality, (1280, 720))
    
    def _create_background(self, width, height, duration, background_type):
        """Create background clip"""
        if background_type == 'gradient':
            # Create gradient background
            gradient = self._create_gradient_image(width, height)
            return ImageClip(gradient, duration=duration)
        
        elif background_type == 'custom':
            # Use custom background if available
            custom_bg_path = os.path.join(self.assets_dir, 'custom_background.jpg')
            if os.path.exists(custom_bg_path):
                return ImageClip(custom_bg_path, duration=duration).resize((width, height))
        
        # Default: simple color background
        return ColorClip(size=(width, height), color=(45, 55, 72), duration=duration)
    
    def _create_avatar(self, width, height, duration, avatar_type):
        """Create avatar clip"""
        if avatar_type == 'animated':
            # Create simple animated avatar
            return self._create_animated_avatar(width, height, duration)
        
        elif avatar_type == 'slideshow':
            # Create slideshow-style avatar
            return self._create_slideshow_avatar(width, height, duration)
        
        # Default: static avatar
        avatar_size = min(width, height) // 4
        avatar_clip = ImageClip(self.default_avatar_path, duration=duration)
        return avatar_clip.resize((avatar_size, avatar_size))
    
    def _create_title_overlay(self, width, height, duration, title):
        """Create title text overlay"""
        try:
            # Create title image
            title_img = self._create_text_image(
                title, width, height // 8, 
                font_size=max(24, width // 40),
                color='white'
            )
            
            return ImageClip(title_img, duration=min(duration, 5.0))
            
        except Exception as e:
            logger.warning(f"Title overlay creation failed: {e}")
            return ColorClip(size=(width, height // 8), color=(0, 0, 0, 0), duration=duration)
    
    def _create_waveform(self, audio_path, width, height, duration):
        """Create waveform visualization"""
        try:
            # Simple waveform placeholder
            waveform_height = height // 10
            waveform_clip = ColorClip(
                size=(width // 2, waveform_height), 
                color=(100, 200, 255), 
                duration=duration
            )
            
            return waveform_clip
            
        except Exception as e:
            logger.warning(f"Waveform creation failed: {e}")
            return ColorClip(size=(width, height // 10), color=(0, 0, 0, 0), duration=duration)
    
    def _create_default_avatar(self):
        """Create default avatar image"""
        try:
            size = (300, 300)
            img = Image.new('RGBA', size, color=(100, 100, 100, 255))
            draw = ImageDraw.Draw(img)
            
            # Draw simple avatar
            center = (size[0] // 2, size[1] // 2)
            
            # Face circle
            face_radius = size[0] // 3
            draw.ellipse(
                [center[0] - face_radius, center[1] - face_radius,
                 center[0] + face_radius, center[1] + face_radius],
                fill=(200, 200, 200, 255)
            )
            
            # Eyes
            eye_size = face_radius // 8
            draw.ellipse(
                [center[0] - face_radius // 2, center[1] - face_radius // 3,
                 center[0] - face_radius // 2 + eye_size * 2, center[1] - face_radius // 3 + eye_size * 2],
                fill=(50, 50, 50, 255)
            )
            draw.ellipse(
                [center[0] + face_radius // 2 - eye_size * 2, center[1] - face_radius // 3,
                 center[0] + face_radius // 2, center[1] - face_radius // 3 + eye_size * 2],
                fill=(50, 50, 50, 255)
            )
            
            # Mouth
            draw.arc(
                [center[0] - face_radius // 3, center[1],
                 center[0] + face_radius // 3, center[1] + face_radius // 2],
                start=0, end=180, fill=(50, 50, 50, 255), width=3
            )
            
            img.save(self.default_avatar_path, 'PNG')
            logger.info(f"Default avatar created: {self.default_avatar_path}")
            
        except Exception as e:
            logger.error(f"Failed to create default avatar: {e}")
    
    def _create_gradient_image(self, width, height):
        """Create gradient background image"""
        img = Image.new('RGB', (width, height))
        pixels = img.load()
        
        for y in range(height):
            for x in range(width):
                # Create blue gradient
                r = int(45 + (y / height) * 20)
                g = int(55 + (y / height) * 30)
                b = int(72 + (y / height) * 50)
                pixels[x, y] = (r, g, b)
        
        return np.array(img)
    
    def _create_text_image(self, text, width, height, font_size=32, color='white'):
        """Create text image"""
        img = Image.new('RGBA', (width, height), color=(0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        
        try:
            # Try to use a nice font
            font = ImageFont.truetype("arial.ttf", font_size)
        except:
            font = ImageFont.load_default()
        
        # Get text size
        text_bbox = draw.textbbox((0, 0), text, font=font)
        text_width = text_bbox[2] - text_bbox[0]
        text_height = text_bbox[3] - text_bbox[1]
        
        # Center text
        x = (width - text_width) // 2
        y = (height - text_height) // 2
        
        # Draw text with outline for better visibility
        outline_color = 'black' if color == 'white' else 'white'
        for adj in [-1, -1, 0, 1, 1]:
            for adj2 in [-1, 0, 1, -1, 1]:
                draw.text((x + adj, y + adj2), text, font=font, fill=outline_color)
        
        draw.text((x, y), text, font=font, fill=color)
        
        return np.array(img)
    
    def _create_animated_avatar(self, width, height, duration):
        """Create simple animated avatar"""
        avatar_size = min(width, height) // 4
        
        def make_frame(t):
            # Simple pulsing animation
            scale = 1.0 + 0.1 * np.sin(2 * np.pi * t)
            size = int(avatar_size * scale)
            
            img = Image.new('RGBA', (avatar_size, avatar_size), color=(0, 0, 0, 0))
            draw = ImageDraw.Draw(img)
            
            center = (avatar_size // 2, avatar_size // 2)
            radius = size // 2
            
            draw.ellipse(
                [center[0] - radius, center[1] - radius,
                 center[0] + radius, center[1] + radius],
                fill=(100, 200, 255, 200)
            )
            
            return np.array(img)
        
        return VideoClip(make_frame, duration=duration)
    
    def _create_slideshow_avatar(self, width, height, duration):
        """Create slideshow-style avatar"""
        return self._create_avatar(width, height, duration, 'static')  # Simplified for now
    
    def _generate_thumbnail(self, video_clip, video_path):
        """Generate video thumbnail"""
        try:
            thumbnail_path = video_path.replace('.mp4', '_thumb.jpg')
            video_clip.save_frame(thumbnail_path, t=video_clip.duration / 2)
            return thumbnail_path
        except Exception as e:
            logger.warning(f"Thumbnail generation failed: {e}")
            return None