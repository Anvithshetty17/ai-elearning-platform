import os
import logging
import requests
import json
from cloudinary import uploader, config

logger = logging.getLogger(__name__)

class NotificationService:
    """Service for updating lecture status and uploading files"""
    
    def __init__(self):
        self.backend_url = os.getenv('BACKEND_URL', 'http://localhost:5000')
        self.setup_cloudinary()
    
    def setup_cloudinary(self):
        """Setup Cloudinary configuration"""
        try:
            config(
                cloud_name=os.getenv('CLOUDINARY_CLOUD_NAME'),
                api_key=os.getenv('CLOUDINARY_API_KEY'),
                api_secret=os.getenv('CLOUDINARY_API_SECRET')
            )
            logger.info("Cloudinary configured successfully")
        except Exception as e:
            logger.error(f"Cloudinary setup failed: {e}")
    
    def update_lecture_status(self, lecture_id, status, stage=None, progress=None, data=None, error_message=None):
        """Update lecture processing status"""
        try:
            url = f"{self.backend_url}/api/lectures/{lecture_id}/status"
            
            payload = {
                'status': status,
                'stage': stage,
                'progress': progress
            }
            
            if data:
                payload.update(data)
            
            if error_message:
                payload['errorMessage'] = error_message
            
            response = requests.patch(url, json=payload, timeout=10)
            
            if response.status_code == 200:
                logger.info(f"Status updated for lecture {lecture_id}: {status}")
                return True
            else:
                logger.error(f"Failed to update status: {response.status_code} - {response.text}")
                return False
                
        except Exception as e:
            logger.error(f"Status update failed for lecture {lecture_id}: {str(e)}")
            return False
    
    def upload_lecture_files(self, lecture_id, files_data):
        """Upload generated files to cloud storage"""
        try:
            logger.info(f"Uploading files for lecture {lecture_id}")
            
            upload_results = {}
            
            # Upload video file
            if 'video_path' in files_data and os.path.exists(files_data['video_path']):
                video_result = self._upload_to_cloudinary(
                    files_data['video_path'],
                    f"ai-elearning/videos/lecture_{lecture_id}",
                    resource_type="video"
                )
                if video_result:
                    upload_results['video_url'] = video_result['secure_url']
                    upload_results['video_public_id'] = video_result['public_id']
            
            # Upload audio file
            if 'audio_path' in files_data and os.path.exists(files_data['audio_path']):
                audio_result = self._upload_to_cloudinary(
                    files_data['audio_path'],
                    f"ai-elearning/audio/lecture_{lecture_id}",
                    resource_type="video"  # Cloudinary handles audio as video
                )
                if audio_result:
                    upload_results['audio_url'] = audio_result['secure_url']
                    upload_results['audio_public_id'] = audio_result['public_id']
            
            # Upload thumbnail
            if 'thumbnail_path' in files_data and files_data['thumbnail_path'] and os.path.exists(files_data['thumbnail_path']):
                thumbnail_result = self._upload_to_cloudinary(
                    files_data['thumbnail_path'],
                    f"ai-elearning/thumbnails/lecture_{lecture_id}",
                    resource_type="image"
                )
                if thumbnail_result:
                    upload_results['thumbnail_url'] = thumbnail_result['secure_url']
                    upload_results['thumbnail_public_id'] = thumbnail_result['public_id']
            
            if upload_results:
                logger.info(f"Files uploaded successfully for lecture {lecture_id}")
                return {
                    'success': True,
                    **upload_results
                }
            else:
                return {
                    'success': False,
                    'error': 'No files were uploaded'
                }
                
        except Exception as e:
            logger.error(f"File upload failed for lecture {lecture_id}: {str(e)}")
            return {
                'success': False,
                'error': str(e)
            }
    
    def _upload_to_cloudinary(self, file_path, public_id, resource_type="image"):
        """Upload file to Cloudinary"""
        try:
            result = uploader.upload(
                file_path,
                public_id=public_id,
                resource_type=resource_type,
                overwrite=True
            )
            logger.info(f"Uploaded to Cloudinary: {result['secure_url']}")
            return result
            
        except Exception as e:
            logger.error(f"Cloudinary upload failed: {e}")
            return None