import os
import tempfile
import logging
from gtts import gTTS
import pyttsx3
from pydub import AudioSegment
import soundfile as sf
import librosa

logger = logging.getLogger(__name__)

class TTSService:
    """Text-to-Speech service using gTTS and pyttsx3"""
    
    def __init__(self):
        self.engine = None
        self.initialize_engines()
    
    def initialize_engines(self):
        """Initialize TTS engines"""
        try:
            # Initialize pyttsx3 engine for offline TTS
            self.engine = pyttsx3.init()
            logger.info("pyttsx3 engine initialized successfully")
        except Exception as e:
            logger.warning(f"Failed to initialize pyttsx3: {e}")
            self.engine = None
    
    def is_available(self):
        """Check if TTS service is available"""
        try:
            # Test gTTS (online)
            test_tts = gTTS("test", lang='en')
            return True
        except:
            # Fallback to pyttsx3 (offline)
            return self.engine is not None
    
    def generate_speech(self, text, language='en', speed=1.0, pitch=1.0, voice='default'):
        """
        Generate speech from text
        
        Args:
            text (str): Text to convert to speech
            language (str): Language code (e.g., 'en', 'es', 'fr')
            speed (float): Speech speed multiplier (0.5-2.0)
            pitch (float): Pitch multiplier (0.5-2.0) 
            voice (str): Voice type ('default', 'male', 'female')
            
        Returns:
            dict: Result with audio_path and duration or error
        """
        try:
            logger.info(f"Generating speech: {len(text)} chars, lang: {language}")
            
            if len(text.strip()) == 0:
                return {
                    'success': False,
                    'error': 'Text content is empty'
                }
            
            # Create temporary file
            output_path = os.path.join(
                tempfile.gettempdir(),
                f"tts_{int(os.urandom(4).hex(), 16)}.wav"
            )
            
            # Try gTTS first (online, better quality)
            if self._generate_with_gtts(text, language, output_path):
                # Apply speed and pitch modifications
                output_path = self._apply_audio_effects(
                    output_path, speed, pitch
                )
                duration = self._get_audio_duration(output_path)
                
                return {
                    'success': True,
                    'audio_path': output_path,
                    'duration': duration,
                    'method': 'gTTS'
                }
            
            # Fallback to pyttsx3 (offline)
            elif self._generate_with_pyttsx3(text, language, speed, voice, output_path):
                duration = self._get_audio_duration(output_path)
                
                return {
                    'success': True,
                    'audio_path': output_path,
                    'duration': duration,
                    'method': 'pyttsx3'
                }
            
            else:
                return {
                    'success': False,
                    'error': 'All TTS engines failed'
                }
                
        except Exception as e:
            logger.error(f"TTS generation error: {str(e)}")
            return {
                'success': False,
                'error': f'Speech generation failed: {str(e)}'
            }
    
    def _generate_with_gtts(self, text, language, output_path):
        """Generate speech using gTTS (Google Text-to-Speech)"""
        try:
            # Map language codes
            lang_map = {
                'en': 'en',
                'es': 'es',
                'fr': 'fr',
                'de': 'de',
                'it': 'it',
                'pt': 'pt',
                'ru': 'ru',
                'ja': 'ja',
                'ko': 'ko',
                'zh': 'zh-cn'
            }
            
            gtts_lang = lang_map.get(language, 'en')
            
            # Generate speech
            tts = gTTS(text=text, lang=gtts_lang, slow=False)
            
            # Save to temporary MP3 file
            temp_mp3 = output_path.replace('.wav', '.mp3')
            tts.save(temp_mp3)
            
            # Convert MP3 to WAV
            audio = AudioSegment.from_mp3(temp_mp3)
            audio.export(output_path, format="wav")
            
            # Cleanup MP3
            if os.path.exists(temp_mp3):
                os.remove(temp_mp3)
            
            logger.info(f"gTTS generation successful: {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"gTTS failed: {str(e)}")
            return False
    
    def _generate_with_pyttsx3(self, text, language, speed, voice, output_path):
        """Generate speech using pyttsx3 (offline TTS)"""
        try:
            if not self.engine:
                return False
            
            # Configure engine
            voices = self.engine.getProperty('voices')
            
            # Select voice based on preference
            if voice == 'female' and len(voices) > 1:
                self.engine.setProperty('voice', voices[1].id)
            elif voice == 'male' and len(voices) > 0:
                self.engine.setProperty('voice', voices[0].id)
            
            # Set speech rate
            rate = self.engine.getProperty('rate')
            self.engine.setProperty('rate', rate * speed)
            
            # Generate speech
            self.engine.save_to_file(text, output_path)
            self.engine.runAndWait()
            
            logger.info(f"pyttsx3 generation successful: {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"pyttsx3 failed: {str(e)}")
            return False
    
    def _apply_audio_effects(self, audio_path, speed, pitch):
        """Apply speed and pitch effects to audio"""
        try:
            if speed == 1.0 and pitch == 1.0:
                return audio_path
            
            # Load audio
            y, sr = librosa.load(audio_path, sr=None)
            
            # Apply speed change
            if speed != 1.0:
                y = librosa.effects.time_stretch(y, rate=speed)
            
            # Apply pitch change
            if pitch != 1.0:
                n_steps = 12 * (pitch - 1.0)  # Convert to semitones
                y = librosa.effects.pitch_shift(y, sr=sr, n_steps=n_steps)
            
            # Save modified audio
            modified_path = audio_path.replace('.wav', '_modified.wav')
            sf.write(modified_path, y, sr)
            
            # Replace original
            if os.path.exists(audio_path):
                os.remove(audio_path)
            os.rename(modified_path, audio_path)
            
            return audio_path
            
        except Exception as e:
            logger.warning(f"Audio effects failed: {e}")
            return audio_path  # Return original on failure
    
    def _get_audio_duration(self, audio_path):
        """Get audio duration in seconds"""
        try:
            audio = AudioSegment.from_wav(audio_path)
            return len(audio) / 1000.0  # Convert ms to seconds
        except Exception as e:
            logger.warning(f"Failed to get audio duration: {e}")
            return 0.0