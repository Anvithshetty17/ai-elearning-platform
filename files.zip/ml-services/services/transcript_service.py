import os
import tempfile
import logging
import speech_recognition as sr
from pydub import AudioSegment
import json

logger = logging.getLogger(__name__)

class TranscriptService:
    """Speech-to-text transcript generation service"""
    
    def __init__(self):
        self.recognizer = sr.Recognizer()
        self.initialize_service()
    
    def initialize_service(self):
        """Initialize speech recognition service"""
        try:
            # Configure recognizer settings
            self.recognizer.energy_threshold = 300
            self.recognizer.dynamic_energy_threshold = True
            self.recognizer.pause_threshold = 0.8
            logger.info("Speech recognition service initialized")
        except Exception as e:
            logger.error(f"Failed to initialize transcript service: {e}")
    
    def is_available(self):
        """Check if transcript service is available"""
        try:
            # Test speech recognition
            return True
        except Exception as e:
            logger.error(f"Transcript service unavailable: {e}")
            return False
    
    def generate_transcript(self, audio_path, language='en'):
        """
        Generate transcript from audio file
        
        Args:
            audio_path (str): Path to audio file
            language (str): Language code for recognition
            
        Returns:
            dict: Result with transcript text or error
        """
        try:
            logger.info(f"Generating transcript: {audio_path}, language: {language}")
            
            if not os.path.exists(audio_path):
                return {
                    'success': False,
                    'error': 'Audio file not found'
                }
            
            # Convert audio to WAV format for speech recognition
            wav_path = self._convert_to_wav(audio_path)
            
            # Split audio into chunks for better recognition
            chunks = self._split_audio(wav_path)
            
            transcript_parts = []
            
            for i, chunk_path in enumerate(chunks):
                logger.info(f"Processing chunk {i+1}/{len(chunks)}")
                
                chunk_transcript = self._recognize_chunk(chunk_path, language)
                if chunk_transcript:
                    transcript_parts.append(chunk_transcript)
                
                # Cleanup chunk file
                if os.path.exists(chunk_path):
                    os.remove(chunk_path)
            
            # Combine transcript parts
            full_transcript = ' '.join(transcript_parts)
            
            # Save transcript to file
            transcript_path = self._save_transcript(full_transcript, audio_path)
            
            # Cleanup temporary files
            if wav_path != audio_path and os.path.exists(wav_path):
                os.remove(wav_path)
            
            logger.info(f"Transcript generated: {len(full_transcript)} characters")
            
            return {
                'success': True,
                'transcript': full_transcript,
                'transcript_path': transcript_path,
                'word_count': len(full_transcript.split()),
                'method': 'speech_recognition'
            }
            
        except Exception as e:
            logger.error(f"Transcript generation error: {str(e)}")
            return {
                'success': False,
                'error': f'Transcript generation failed: {str(e)}'
            }
    
    def _convert_to_wav(self, audio_path):
        """Convert audio file to WAV format"""
        try:
            if audio_path.lower().endswith('.wav'):
                return audio_path
            
            # Convert to WAV
            audio = AudioSegment.from_file(audio_path)
            wav_path = audio_path.rsplit('.', 1)[0] + '_converted.wav'
            
            # Export with speech recognition friendly settings
            audio = audio.set_frame_rate(16000).set_channels(1)
            audio.export(wav_path, format="wav")
            
            return wav_path
            
        except Exception as e:
            logger.error(f"Audio conversion failed: {e}")
            raise
    
    def _split_audio(self, audio_path, chunk_length_ms=30000):
        """Split audio into smaller chunks for better recognition"""
        try:
            audio = AudioSegment.from_wav(audio_path)
            chunks = []
            
            # If audio is shorter than chunk length, return as single chunk
            if len(audio) <= chunk_length_ms:
                return [audio_path]
            
            # Split into chunks
            for i, start in enumerate(range(0, len(audio), chunk_length_ms)):
                chunk = audio[start:start + chunk_length_ms]
                
                if len(chunk) < 1000:  # Skip very short chunks
                    continue
                
                chunk_path = os.path.join(
                    tempfile.gettempdir(),
                    f"chunk_{i}_{int(os.urandom(2).hex(), 16)}.wav"
                )
                
                chunk.export(chunk_path, format="wav")
                chunks.append(chunk_path)
            
            return chunks
            
        except Exception as e:
            logger.error(f"Audio splitting failed: {e}")
            return [audio_path]  # Return original if splitting fails
    
    def _recognize_chunk(self, chunk_path, language):
        """Recognize speech in audio chunk"""
        try:
            with sr.AudioFile(chunk_path) as source:
                # Adjust for ambient noise
                self.recognizer.adjust_for_ambient_noise(source, duration=0.5)
                
                # Record audio
                audio = self.recognizer.record(source)
                
                # Map language codes
                lang_map = {
                    'en': 'en-US',
                    'es': 'es-ES',
                    'fr': 'fr-FR',
                    'de': 'de-DE',
                    'it': 'it-IT',
                    'pt': 'pt-PT',
                    'ru': 'ru-RU',
                    'ja': 'ja-JP',
                    'ko': 'ko-KR',
                    'zh': 'zh-CN'
                }
                
                recognition_lang = lang_map.get(language, 'en-US')
                
                # Try Google Speech Recognition first
                try:
                    text = self.recognizer.recognize_google(audio, language=recognition_lang)
                    return text.strip()
                except sr.RequestError:
                    logger.warning("Google Speech Recognition service unavailable")
                
                # Fallback to offline recognition
                try:
                    text = self.recognizer.recognize_sphinx(audio)
                    return text.strip()
                except sr.RequestError:
                    logger.warning("Sphinx recognition unavailable")
                
                return None
                
        except sr.UnknownValueError:
            logger.warning(f"Could not understand audio in chunk: {chunk_path}")
            return None
        except Exception as e:
            logger.error(f"Chunk recognition failed: {e}")
            return None
    
    def _save_transcript(self, transcript, audio_path):
        """Save transcript to file"""
        try:
            transcript_path = audio_path.rsplit('.', 1)[0] + '_transcript.txt'
            
            with open(transcript_path, 'w', encoding='utf-8') as f:
                f.write(transcript)
            
            # Also save as JSON with metadata
            json_path = audio_path.rsplit('.', 1)[0] + '_transcript.json'
            transcript_data = {
                'transcript': transcript,
                'word_count': len(transcript.split()),
                'generated_at': os.path.getctime(audio_path),
                'audio_file': os.path.basename(audio_path)
            }
            
            with open(json_path, 'w', encoding='utf-8') as f:
                json.dump(transcript_data, f, ensure_ascii=False, indent=2)
            
            return transcript_path
            
        except Exception as e:
            logger.error(f"Failed to save transcript: {e}")
            return None
    
    def generate_subtitles(self, audio_path, transcript, language='en'):
        """Generate subtitle file (SRT format)"""
        try:
            # Simple subtitle generation - split transcript into time-based chunks
            words = transcript.split()
            words_per_subtitle = 10
            duration_per_word = 0.5  # Approximate
            
            subtitles = []
            
            for i in range(0, len(words), words_per_subtitle):
                start_time = i * duration_per_word
                end_time = min((i + words_per_subtitle) * duration_per_word, len(words) * duration_per_word)
                
                subtitle_text = ' '.join(words[i:i + words_per_subtitle])
                
                subtitles.append({
                    'start': self._format_time(start_time),
                    'end': self._format_time(end_time),
                    'text': subtitle_text
                })
            
            # Save SRT file
            srt_path = audio_path.rsplit('.', 1)[0] + '_subtitles.srt'
            
            with open(srt_path, 'w', encoding='utf-8') as f:
                for i, subtitle in enumerate(subtitles, 1):
                    f.write(f"{i}\n")
                    f.write(f"{subtitle['start']} --> {subtitle['end']}\n")
                    f.write(f"{subtitle['text']}\n\n")
            
            return srt_path
            
        except Exception as e:
            logger.error(f"Subtitle generation failed: {e}")
            return None
    
    def _format_time(self, seconds):
        """Format time for SRT subtitles (HH:MM:SS,mmm)"""
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        secs = int(seconds % 60)
        millisecs = int((seconds % 1) * 1000)
        
        return f"{hours:02d}:{minutes:02d}:{secs:02d},{millisecs:03d}"