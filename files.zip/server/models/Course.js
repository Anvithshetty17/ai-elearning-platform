const mongoose = require('mongoose');

const courseSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Course name is required'],
    trim: true,
    maxLength: [200, 'Course name cannot exceed 200 characters'],
    minLength: [3, 'Course name must be at least 3 characters']
  },
  description: {
    type: String,
    trim: true,
    maxLength: [2000, 'Description cannot exceed 2000 characters']
  },
  professor: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: [true, 'Professor is required'],
    index: true
  },
  lectures: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Lecture'
  }],
  students: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }],
  category: {
    type: String,
    trim: true,
    maxLength: [100, 'Category cannot exceed 100 characters'],
    enum: {
      values: [
        'Computer Science', 'Mathematics', 'Physics', 'Chemistry', 
        'Biology', 'Engineering', 'Business', 'Literature', 
        'History', 'Art', 'Music', 'Language', 'Other'
      ],
      message: 'Please select a valid category'
    }
  },
  difficulty: {
    type: String,
    enum: {
      values: ['beginner', 'intermediate', 'advanced'],
      message: 'Difficulty must be beginner, intermediate, or advanced'
    },
    default: 'beginner'
  },
  tags: [{
    type: String,
    trim: true,
    maxLength: [50, 'Tag cannot exceed 50 characters']
  }],
  thumbnail: {
    public_id: String,
    url: {
      type: String,
      default: ''
    }
  },
  isPublished: {
    type: Boolean,
    default: false
  },
  enrollmentCount: {
    type: Number,
    default: 0,
    min: [0, 'Enrollment count cannot be negative']
  },
  maxStudents: {
    type: Number,
    default: 1000,
    min: [1, 'Maximum students must be at least 1']
  },
  price: {
    type: Number,
    default: 0,
    min: [0, 'Price cannot be negative']
  },
  currency: {
    type: String,
    default: 'USD',
    enum: ['USD', 'EUR', 'GBP', 'INR', 'JPY']
  },
  language: {
    type: String,
    default: 'English',
    trim: true
  },
  prerequisites: [{
    type: String,
    trim: true,
    maxLength: [200, 'Prerequisite cannot exceed 200 characters']
  }],
  learningOutcomes: [{
    type: String,
    trim: true,
    maxLength: [300, 'Learning outcome cannot exceed 300 characters']
  }],
  duration: {
    type: Number, // in minutes
    default: 0,
    min: [0, 'Duration cannot be negative']
  },
  rating: {
    average: {
      type: Number,
      default: 0,
      min: [0, 'Rating cannot be negative'],
      max: [5, 'Rating cannot exceed 5']
    },
    count: {
      type: Number,
      default: 0,
      min: [0, 'Rating count cannot be negative']
    }
  },
  isActive: {
    type: Boolean,
    default: true
  },
  enrollmentStartDate: {
    type: Date
  },
  enrollmentEndDate: {
    type: Date
  },
  courseStartDate: {
    type: Date
  },
  courseEndDate: {
    type: Date
  }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Indexes for better performance
courseSchema.index({ name: 'text', description: 'text', tags: 'text' });
courseSchema.index({ professor: 1, createdAt: -1 });
courseSchema.index({ category: 1, difficulty: 1 });
courseSchema.index({ isPublished: 1, isActive: 1 });
courseSchema.index({ rating: -1 });
courseSchema.index({ enrollmentCount: -1 });
courseSchema.index({ createdAt: -1 });

// Virtual for total lectures count
courseSchema.virtual('lectureCount').get(function() {
  return this.lectures ? this.lectures.length : 0;
});

// Virtual for enrollment status
courseSchema.virtual('enrollmentStatus').get(function() {
  if (this.enrollmentEndDate && this.enrollmentEndDate < new Date()) {
    return 'closed';
  }
  if (this.enrollmentStartDate && this.enrollmentStartDate > new Date()) {
    return 'upcoming';
  }
  if (this.enrollmentCount >= this.maxStudents) {
    return 'full';
  }
  return 'open';
});

// Virtual for course status
courseSchema.virtual('courseStatus').get(function() {
  const now = new Date();
  if (this.courseStartDate && this.courseStartDate > now) {
    return 'upcoming';
  }
  if (this.courseEndDate && this.courseEndDate < now) {
    return 'completed';
  }
  if (this.courseStartDate && this.courseStartDate <= now) {
    return 'ongoing';
  }
  return 'draft';
});

// Virtual for course URL slug
courseSchema.virtual('slug').get(function() {
  return this.name.toLowerCase().replace(/[^a-zA-Z0-9]/g, '-').replace(/-+/g, '-');
});

// Pre-save middleware to update duration based on lectures
courseSchema.pre('save', async function(next) {
  if (this.isModified('lectures') && this.lectures.length > 0) {
    try {
      const Lecture = mongoose.model('Lecture');
      const lectures = await Lecture.find({ 
        _id: { $in: this.lectures } 
      }).select('duration');
      
      this.duration = lectures.reduce((total, lecture) => {
        return total + (lecture.duration || 0);
      }, 0);
    } catch (error) {
      console.error('Error calculating course duration:', error);
    }
  }
  next();
});

// Method to check if user is enrolled
courseSchema.methods.isUserEnrolled = function(userId) {
  return this.students.some(student => student.toString() === userId.toString());
};

// Method to enroll a student
courseSchema.methods.enrollStudent = async function(userId) {
  if (this.isUserEnrolled(userId)) {
    throw new Error('User is already enrolled in this course');
  }
  
  if (this.enrollmentCount >= this.maxStudents) {
    throw new Error('Course is full');
  }
  
  if (this.enrollmentStatus !== 'open') {
    throw new Error('Enrollment is not currently open for this course');
  }
  
  this.students.push(userId);
  this.enrollmentCount += 1;
  
  return this.save();
};

// Method to unenroll a student
courseSchema.methods.unenrollStudent = async function(userId) {
  if (!this.isUserEnrolled(userId)) {
    throw new Error('User is not enrolled in this course');
  }
  
  this.students = this.students.filter(
    student => student.toString() !== userId.toString()
  );
  this.enrollmentCount = Math.max(0, this.enrollmentCount - 1);
  
  return this.save();
};

// Method to add a lecture
courseSchema.methods.addLecture = async function(lectureId) {
  if (!this.lectures.includes(lectureId)) {
    this.lectures.push(lectureId);
    await this.save();
  }
  return this;
};

// Method to remove a lecture
courseSchema.methods.removeLecture = async function(lectureId) {
  this.lectures = this.lectures.filter(
    lecture => lecture.toString() !== lectureId.toString()
  );
  return this.save();
};

// Method to update rating
courseSchema.methods.updateRating = function(newRating) {
  const currentTotal = this.rating.average * this.rating.count;
  this.rating.count += 1;
  this.rating.average = (currentTotal + newRating) / this.rating.count;
  
  return this.save();
};

// Static method to get popular courses
courseSchema.statics.getPopularCourses = function(limit = 10) {
  return this.find({ 
    isPublished: true, 
    isActive: true 
  })
    .sort({ enrollmentCount: -1, 'rating.average': -1 })
    .limit(limit)
    .populate('professor', 'name avatar')
    .select('name description thumbnail category difficulty enrollmentCount rating duration');
};

// Static method to search courses
courseSchema.statics.searchCourses = function(query, options = {}) {
  const {
    category,
    difficulty,
    minRating = 0,
    maxPrice,
    language,
    page = 1,
    limit = 10,
    sortBy = 'createdAt',
    sortOrder = -1
  } = options;
  
  const filter = {
    isPublished: true,
    isActive: true,
    'rating.average': { $gte: minRating }
  };
  
  if (query) {
    filter.$text = { $search: query };
  }
  
  if (category) filter.category = category;
  if (difficulty) filter.difficulty = difficulty;
  if (language) filter.language = language;
  if (maxPrice !== undefined) filter.price = { $lte: maxPrice };
  
  const sortOptions = {};
  sortOptions[sortBy] = sortOrder;
  
  return this.find(filter)
    .sort(sortOptions)
    .limit(limit)
    .skip((page - 1) * limit)
    .populate('professor', 'name avatar')
    .select('name description thumbnail category difficulty price currency enrollmentCount rating duration language');
};

// Static method to get course statistics
courseSchema.statics.getStats = async function() {
  const totalCourses = await this.countDocuments({ isActive: true });
  const publishedCourses = await this.countDocuments({ isPublished: true, isActive: true });
  const totalEnrollments = await this.aggregate([
    { $match: { isActive: true } },
    { $group: { _id: null, total: { $sum: '$enrollmentCount' } } }
  ]);
  
  const categoryStats = await this.aggregate([
    { $match: { isPublished: true, isActive: true } },
    { $group: { _id: '$category', count: { $sum: 1 } } },
    { $sort: { count: -1 } }
  ]);
  
  return {
    totalCourses,
    publishedCourses,
    totalEnrollments: totalEnrollments[0]?.total || 0,
    categoryStats
  };
};

module.exports = mongoose.model('Course', courseSchema);