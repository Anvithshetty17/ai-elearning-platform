const mongoose = require('mongoose');

const lectureSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, 'Lecture title is required'],
    trim: true,
    maxLength: [300, 'Title cannot exceed 300 characters'],
    minLength: [3, 'Title must be at least 3 characters']
  },
  description: {
    type: String,
    trim: true,
    maxLength: [2000, 'Description cannot exceed 2000 characters']
  },
  professor: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: [true, 'Professor is required'],
    index: true
  },
  course: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Course',
    required: [true, 'Course is required'],
    index: true
  },
  textContent: {
    type: String,
    required: [true, 'Text content is required'],
    maxLength: [50000, 'Text content cannot exceed 50,000 characters']
  },
  audioUrl: {
    public_id: String,
    url: {
      type: String,
      default: ''
    }
  },
  videoUrl: {
    public_id: String,
    url: {
      type: String,
      default: ''
    }
  },
  thumbnailUrl: {
    public_id: String,
    url: {
      type: String,
      default: ''
    }
  },
  transcriptPath: {
    type: String,
    default: ''
  },
  transcript: {
    type: String,
    default: ''
  },
  status: {
    type: String,
    enum: {
      values: ['pending', 'processing', 'completed', 'failed', 'cancelled'],
      message: 'Status must be pending, processing, completed, failed, or cancelled'
    },
    default: 'pending',
    index: true
  },
  processingProgress: {
    type: Number,
    default: 0,
    min: [0, 'Progress cannot be negative'],
    max: [100, 'Progress cannot exceed 100']
  },
  processingStage: {
    type: String,
    enum: ['text-analysis', 'tts-conversion', 'video-generation', 'upload', 'completed'],
    default: 'text-analysis'
  },
  duration: {
    type: Number, // in seconds
    default: 0,
    min: [0, 'Duration cannot be negative']
  },
  views: {
    type: Number,
    default: 0,
    min: [0, 'Views cannot be negative']
  },
  tags: [{
    type: String,
    trim: true,
    maxLength: [50, 'Tag cannot exceed 50 characters']
  }],
  language: {
    type: String,
    default: 'en',
    enum: {
      values: ['en', 'es', 'fr', 'de', 'it', 'pt', 'ru', 'ja', 'ko', 'zh'],
      message: 'Language code not supported'
    }
  },
  voiceSettings: {
    speed: {
      type: Number,
      default: 1.0,
      min: [0.5, 'Voice speed cannot be less than 0.5'],
      max: [2.0, 'Voice speed cannot exceed 2.0']
    },
    pitch: {
      type: Number,
      default: 1.0,
      min: [0.5, 'Voice pitch cannot be less than 0.5'],
      max: [2.0, 'Voice pitch cannot exceed 2.0']
    },
    voice: {
      type: String,
      default: 'default',
      enum: ['default', 'male', 'female', 'robotic']
    }
  },
  videoSettings: {
    quality: {
      type: String,
      default: '720p',
      enum: ['480p', '720p', '1080p']
    },
    avatarType: {
      type: String,
      default: 'static',
      enum: ['static', 'animated', 'slideshow']
    },
    backgroundType: {
      type: String,
      default: 'simple',
      enum: ['simple', 'gradient', 'custom']
    }
  },
  isPublished: {
    type: Boolean,
    default: false
  },
  publishedAt: {
    type: Date
  },
  isActive: {
    type: Boolean,
    default: true
  },
  order: {
    type: Number,
    default: 0
  },
  downloads: {
    type: Number,
    default: 0,
    min: [0, 'Downloads cannot be negative']
  },
  likes: [{
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    likedAt: {
      type: Date,
      default: Date.now
    }
  }],
  comments: [{
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    content: {
      type: String,
      required: true,
      maxLength: [1000, 'Comment cannot exceed 1000 characters']
    },
    createdAt: {
      type: Date,
      default: Date.now
    },
    isActive: {
      type: Boolean,
      default: true
    }
  }],
  processingLogs: [{
    stage: String,
    message: String,
    timestamp: {
      type: Date,
      default: Date.now
    },
    level: {
      type: String,
      enum: ['info', 'warning', 'error'],
      default: 'info'
    }
  }],
  errorMessage: {
    type: String,
    default: ''
  },
  retryCount: {
    type: Number,
    default: 0,
    min: [0, 'Retry count cannot be negative']
  },
  maxRetries: {
    type: Number,
    default: 3,
    min: [1, 'Max retries must be at least 1']
  }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Indexes for better performance
lectureSchema.index({ professor: 1, createdAt: -1 });
lectureSchema.index({ course: 1, order: 1 });
lectureSchema.index({ status: 1, createdAt: -1 });
lectureSchema.index({ isPublished: 1, isActive: 1 });
lectureSchema.index({ title: 'text', description: 'text', tags: 'text' });
lectureSchema.index({ views: -1 });

// Virtual for formatted duration
lectureSchema.virtual('formattedDuration').get(function() {
  if (!this.duration) return '0:00';
  
  const minutes = Math.floor(this.duration / 60);
  const seconds = this.duration % 60;
  return `${minutes}:${seconds.toString().padStart(2, '0')}`;
});

// Virtual for likes count
lectureSchema.virtual('likesCount').get(function() {
  return this.likes ? this.likes.length : 0;
});

// Virtual for comments count
lectureSchema.virtual('commentsCount').get(function() {
  return this.comments ? this.comments.filter(c => c.isActive).length : 0;
});

// Virtual for processing status
lectureSchema.virtual('processingStatus').get(function() {
  return {
    status: this.status,
    progress: this.processingProgress,
    stage: this.processingStage,
    canRetry: this.status === 'failed' && this.retryCount < this.maxRetries
  };
});

// Pre-save middleware
lectureSchema.pre('save', function(next) {
  // Set published date when first published
  if (this.isModified('isPublished') && this.isPublished && !this.publishedAt) {
    this.publishedAt = new Date();
  }
  
  // Update processing progress based on stage
  if (this.isModified('processingStage')) {
    const stageProgress = {
      'text-analysis': 20,
      'tts-conversion': 40,
      'video-generation': 70,
      'upload': 90,
      'completed': 100
    };
    this.processingProgress = stageProgress[this.processingStage] || this.processingProgress;
  }
  
  next();
});

// Method to increment view count
lectureSchema.methods.incrementViews = function() {
  this.views += 1;
  return this.save({ validateBeforeSave: false });
};

// Method to add like
lectureSchema.methods.addLike = function(userId) {
  const existingLike = this.likes.find(
    like => like.user.toString() === userId.toString()
  );
  
  if (existingLike) {
    throw new Error('User has already liked this lecture');
  }
  
  this.likes.push({ user: userId });
  return this.save();
};

// Method to remove like
lectureSchema.methods.removeLike = function(userId) {
  this.likes = this.likes.filter(
    like => like.user.toString() !== userId.toString()
  );
  return this.save();
};

// Method to add comment
lectureSchema.methods.addComment = function(userId, content) {
  this.comments.push({
    user: userId,
    content: content.trim()
  });
  return this.save();
};

// Method to update processing stage
lectureSchema.methods.updateProcessingStage = function(stage, message = '') {
  this.processingStage = stage;
  this.processingLogs.push({
    stage,
    message,
    level: 'info'
  });
  
  if (stage === 'completed') {
    this.status = 'completed';
    this.processingProgress = 100;
  }
  
  return this.save();
};

// Method to mark as failed
lectureSchema.methods.markAsFailed = function(errorMessage) {
  this.status = 'failed';
  this.errorMessage = errorMessage;
  this.processingLogs.push({
    stage: this.processingStage,
    message: errorMessage,
    level: 'error'
  });
  return this.save();
};

// Method to retry processing
lectureSchema.methods.retryProcessing = function() {
  if (this.retryCount >= this.maxRetries) {
    throw new Error('Maximum retry attempts reached');
  }
  
  this.retryCount += 1;
  this.status = 'pending';
  this.processingStage = 'text-analysis';
  this.processingProgress = 0;
  this.errorMessage = '';
  
  this.processingLogs.push({
    stage: 'retry',
    message: `Retry attempt ${this.retryCount}`,
    level: 'info'
  });
  
  return this.save();
};

// Static method to get lectures by status
lectureSchema.statics.getByStatus = function(status, limit = 10) {
  return this.find({ status, isActive: true })
    .sort({ createdAt: -1 })
    .limit(limit)
    .populate('professor', 'name avatar')
    .populate('course', 'name');
};

// Static method to get popular lectures
lectureSchema.statics.getPopular = function(limit = 10) {
  return this.find({ 
    isPublished: true, 
    isActive: true,
    status: 'completed'
  })
    .sort({ views: -1, likesCount: -1 })
    .limit(limit)
    .populate('professor', 'name avatar')
    .populate('course', 'name');
};

// Static method to search lectures
lectureSchema.statics.searchLectures = function(query, options = {}) {
  const {
    courseId,
    professorId,
    status,
    language,
    page = 1,
    limit = 10,
    sortBy = 'createdAt',
    sortOrder = -1
  } = options;
  
  const filter = {
    isActive: true
  };
  
  if (query) {
    filter.$text = { $search: query };
  }
  
  if (courseId) filter.course = courseId;
  if (professorId) filter.professor = professorId;
  if (status) filter.status = status;
  if (language) filter.language = language;
  
  const sortOptions = {};
  sortOptions[sortBy] = sortOrder;
  
  return this.find(filter)
    .sort(sortOptions)
    .limit(limit)
    .skip((page - 1) * limit)
    .populate('professor', 'name avatar')
    .populate('course', 'name');
};

// Static method to get statistics
lectureSchema.statics.getStats = async function() {
  const totalLectures = await this.countDocuments({ isActive: true });
  const publishedLectures = await this.countDocuments({ 
    isPublished: true, 
    isActive: true 
  });
  
  const statusStats = await this.aggregate([
    { $match: { isActive: true } },
    { $group: { _id: '$status', count: { $sum: 1 } } }
  ]);
  
  const totalViews = await this.aggregate([
    { $match: { isActive: true } },
    { $group: { _id: null, total: { $sum: '$views' } } }
  ]);
  
  const avgDuration = await this.aggregate([
    { $match: { isActive: true, duration: { $gt: 0 } } },
    { $group: { _id: null, avg: { $avg: '$duration' } } }
  ]);
  
  return {
    totalLectures,
    publishedLectures,
    statusStats,
    totalViews: totalViews[0]?.total || 0,
    averageDuration: Math.round(avgDuration[0]?.avg || 0)
  };
};

module.exports = mongoose.model('Lecture', lectureSchema);