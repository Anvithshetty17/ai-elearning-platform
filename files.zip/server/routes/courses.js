const express = require('express');
const { body, validationResult, query } = require('express-validator');
const Course = require('../models/Course');
const Lecture = require('../models/Lecture');
const { authenticateToken, requireRole } = require('../middleware/auth');

const router = express.Router();

// @desc    Create new course
// @route   POST /api/courses
// @access  Private (Professor only)
router.post('/', authenticateToken, requireRole(['professor']), [
  body('name')
    .trim()
    .isLength({ min: 3, max: 200 })
    .withMessage('Course name must be between 3 and 200 characters'),
  body('description')
    .optional()
    .trim()
    .isLength({ max: 2000 })
    .withMessage('Description cannot exceed 2000 characters'),
  body('category')
    .optional()
    .isIn(['Computer Science', 'Mathematics', 'Physics', 'Chemistry', 'Biology', 'Engineering', 'Business', 'Literature', 'History', 'Art', 'Music', 'Language', 'Other'])
    .withMessage('Please select a valid category'),
  body('difficulty')
    .optional()
    .isIn(['beginner', 'intermediate', 'advanced'])
    .withMessage('Difficulty must be beginner, intermediate, or advanced'),
  body('maxStudents')
    .optional()
    .isInt({ min: 1, max: 10000 })
    .withMessage('Maximum students must be between 1 and 10,000'),
  body('price')
    .optional()
    .isFloat({ min: 0 })
    .withMessage('Price cannot be negative')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: errors.array()
      });
    }

    const {
      name,
      description,
      category,
      difficulty,
      maxStudents,
      price,
      currency,
      language,
      prerequisites,
      learningOutcomes,
      tags
    } = req.body;

    const course = new Course({
      name: name.trim(),
      description: description?.trim(),
      professor: req.user._id,
      category,
      difficulty,
      maxStudents: maxStudents || 1000,
      price: price || 0,
      currency: currency || 'USD',
      language: language || 'English',
      prerequisites: prerequisites || [],
      learningOutcomes: learningOutcomes || [],
      tags: tags || []
    });

    await course.save();
    await course.populate('professor', 'name email avatar');

    console.log(`✅ Course created: ${course.name} by ${req.user.name}`);

    res.status(201).json({
      success: true,
      message: 'Course created successfully',
      course
    });
  } catch (error) {
    console.error('❌ Create course error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to create course',
      error: process.env.NODE_ENV === 'development' ? error.message : 'Internal server error'
    });
  }
});

// @desc    Get all courses for current user
// @route   GET /api/courses
// @access  Private
router.get('/', authenticateToken, [
  query('page').optional().isInt({ min: 1 }).withMessage('Page must be a positive integer'),
  query('limit').optional().isInt({ min: 1, max: 100 }).withMessage('Limit must be between 1 and 100'),
  query('status').optional().isIn(['draft', 'published', 'all']).withMessage('Status must be draft, published, or all')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: errors.array()
      });
    }

    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const status = req.query.status || 'all';

    let query = {};
    let populateOptions = [
      { path: 'professor', select: 'name email avatar' },
      { path: 'lectures', select: 'title status duration createdAt views' }
    ];

    if (req.user.role === 'professor') {
      // Get courses created by professor
      query.professor = req.user._id;
      
      if (status === 'published') {
        query.isPublished = true;
      } else if (status === 'draft') {
        query.isPublished = false;
      }
    } else if (req.user.role === 'student') {
      // Get courses student is enrolled in or can browse
      if (status === 'enrolled') {
        query.students = req.user._id;
      } else {
        query.isPublished = true;
        query.isActive = true;
      }
    }

    const courses = await Course.find(query)
      .populate(populateOptions)
      .sort({ createdAt: -1 })
      .limit(limit)
      .skip((page - 1) * limit);

    const total = await Course.countDocuments(query);

    res.json({
      success: true,
      courses,
      pagination: {
        currentPage: page,
        totalPages: Math.ceil(total / limit),
        totalCourses: total,
        hasNext: page < Math.ceil(total / limit),
        hasPrev: page > 1
      }
    });
  } catch (error) {
    console.error('❌ Get courses error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get courses'
    });
  }
});

// @desc    Get single course
// @route   GET /api/courses/:id
// @access  Private
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const course = await Course.findById(req.params.id)
      .populate('professor', 'name email avatar bio')
      .populate({
        path: 'lectures',
        select: 'title description status videoUrl duration views order createdAt',
        match: { isActive: true },
        options: { sort: { order: 1, createdAt: 1 } }
      })
      .populate('students', 'name email avatar');

    if (!course) {
      return res.status(404).json({
        success: false,
        message: 'Course not found'
      });
    }

    // Check access permissions
    const isProfessor = course.professor._id.equals(req.user._id);
    const isEnrolled = course.students.some(student => student._id.equals(req.user._id));
    const isPublished = course.isPublished;

    if (!isProfessor && !isEnrolled && !isPublished) {
      return res.status(403).json({
        success: false,
        message: 'Access denied to this course'
      });
    }

    // Filter sensitive data for students
    let responseData = course.toObject();
    if (req.user.role === 'student' && !isProfessor) {
      delete responseData.students;
      responseData.isEnrolled = isEnrolled;
      responseData.canEnroll = !isEnrolled && course.enrollmentStatus === 'open';
    }

    res.json({
      success: true,
      course: responseData
    });
  } catch (error) {
    console.error('❌ Get course error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get course details'
    });
  }
});

// @desc    Update course
// @route   PUT /api/courses/:id
// @access  Private (Professor only - own courses)
router.put('/:id', authenticateToken, requireRole(['professor']), [
  body('name')
    .optional()
    .trim()
    .isLength({ min: 3, max: 200 })
    .withMessage('Course name must be between 3 and 200 characters'),
  body('description')
    .optional()
    .trim()
    .isLength({ max: 2000 })
    .withMessage('Description cannot exceed 2000 characters'),
  body('category')
    .optional()
    .isIn(['Computer Science', 'Mathematics', 'Physics', 'Chemistry', 'Biology', 'Engineering', 'Business', 'Literature', 'History', 'Art', 'Music', 'Language', 'Other'])
    .withMessage('Please select a valid category'),
  body('difficulty')
    .optional()
    .isIn(['beginner', 'intermediate', 'advanced'])
    .withMessage('Difficulty must be beginner, intermediate, or advanced')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: errors.array()
      });
    }

    const course = await Course.findOne({
      _id: req.params.id,
      professor: req.user._id
    });

    if (!course) {
      return res.status(404).json({
        success: false,
        message: 'Course not found or unauthorized'
      });
    }

    const allowedUpdates = [
      'name', 'description', 'category', 'difficulty', 'maxStudents',
      'price', 'currency', 'language', 'prerequisites', 'learningOutcomes',
      'tags', 'isPublished', 'enrollmentStartDate', 'enrollmentEndDate',
      'courseStartDate', 'courseEndDate'
    ];

    allowedUpdates.forEach(field => {
      if (req.body[field] !== undefined) {
        course[field] = req.body[field];
      }
    });

    await course.save();
    await course.populate('professor', 'name email avatar');

    console.log(`✅ Course updated: ${course.name} by ${req.user.name}`);

    res.json({
      success: true,
      message: 'Course updated successfully',
      course
    });
  } catch (error) {
    console.error('❌ Update course error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update course'
    });
  }
});

// @desc    Delete course
// @route   DELETE /api/courses/:id
// @access  Private (Professor only - own courses)
router.delete('/:id', authenticateToken, requireRole(['professor']), async (req, res) => {
  try {
    const course = await Course.findOne({
      _id: req.params.id,
      professor: req.user._id
    });

    if (!course) {
      return res.status(404).json({
        success: false,
        message: 'Course not found or unauthorized'
      });
    }

    // Soft delete - mark as inactive
    course.isActive = false;
    await course.save();

    // Also mark all lectures as inactive
    await Lecture.updateMany(
      { course: course._id },
      { isActive: false }
    );

    console.log(`✅ Course deleted: ${course.name} by ${req.user.name}`);

    res.json({
      success: true,
      message: 'Course deleted successfully'
    });
  } catch (error) {
    console.error('❌ Delete course error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to delete course'
    });
  }
});

// @desc    Enroll in course
// @route   POST /api/courses/:id/enroll
// @access  Private (Students only)
router.post('/:id/enroll', authenticateToken, requireRole(['student']), async (req, res) => {
  try {
    const course = await Course.findById(req.params.id);
    
    if (!course) {
      return res.status(404).json({
        success: false,
        message: 'Course not found'
      });
    }

    if (!course.isPublished || !course.isActive) {
      return res.status(400).json({
        success: false,
        message: 'Course is not available for enrollment'
      });
    }

    // Check if already enrolled
    if (course.isUserEnrolled(req.user._id)) {
      return res.status(400).json({
        success: false,
        message: 'You are already enrolled in this course'
      });
    }

    // Enroll student
    await course.enrollStudent(req.user._id);
    
    console.log(`✅ Student enrolled: ${req.user.name} in ${course.name}`);

    res.json({
      success: true,
      message: 'Successfully enrolled in course',
      course: {
        id: course._id,
        name: course.name,
        enrollmentCount: course.enrollmentCount
      }
    });
  } catch (error) {
    console.error('❌ Enroll course error:', error);
    
    if (error.message.includes('full') || error.message.includes('open')) {
      return res.status(400).json({
        success: false,
        message: error.message
      });
    }

    res.status(500).json({
      success: false,
      message: 'Failed to enroll in course'
    });
  }
});

// @desc    Unenroll from course
// @route   POST /api/courses/:id/unenroll
// @access  Private (Students only)
router.post('/:id/unenroll', authenticateToken, requireRole(['student']), async (req, res) => {
  try {
    const course = await Course.findById(req.params.id);
    
    if (!course) {
      return res.status(404).json({
        success: false,
        message: 'Course not found'
      });
    }

    // Unenroll student
    await course.unenrollStudent(req.user._id);
    
    console.log(`✅ Student unenrolled: ${req.user.name} from ${course.name}`);

    res.json({
      success: true,
      message: 'Successfully unenrolled from course'
    });
  } catch (error) {
    console.error('❌ Unenroll course error:', error);
    
    if (error.message.includes('not enrolled')) {
      return res.status(400).json({
        success: false,
        message: error.message
      });
    }

    res.status(500).json({
      success: false,
      message: 'Failed to unenroll from course'
    });
  }
});

// @desc    Get public courses for browsing
// @route   GET /api/courses/public/browse
// @access  Public
router.get('/public/browse', [
  query('page').optional().isInt({ min: 1 }).withMessage('Page must be a positive integer'),
  query('limit').optional().isInt({ min: 1, max: 50 }).withMessage('Limit must be between 1 and 50'),
  query('category').optional().isString(),
  query('difficulty').optional().isIn(['beginner', 'intermediate', 'advanced']),
  query('search').optional().isString().isLength({ max: 100 }),
  query('sort').optional().isIn(['newest', 'popular', 'rating', 'name'])
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: errors.array()
      });
    }

    const {
      page = 1,
      limit = 12,
      category,
      difficulty,
      search,
      sort = 'newest'
    } = req.query;

    const filter = {
      isPublished: true,
      isActive: true
    };

    if (category && category !== 'all') filter.category = category;
    if (difficulty && difficulty !== 'all') filter.difficulty = difficulty;
    if (search) filter.$text = { $search: search };

    let sortOptions = {};
    switch (sort) {
      case 'popular':
        sortOptions = { enrollmentCount: -1, 'rating.average': -1 };
        break;
      case 'rating':
        sortOptions = { 'rating.average': -1, 'rating.count': -1 };
        break;
      case 'name':
        sortOptions = { name: 1 };
        break;
      default:
        sortOptions = { createdAt: -1 };
    }

    const courses = await Course.find(filter)
      .populate('professor', 'name avatar')
      .select('name description category difficulty price currency enrollmentCount rating duration language thumbnail createdAt')
      .sort(sortOptions)
      .limit(parseInt(limit))
      .skip((parseInt(page) - 1) * parseInt(limit));

    const total = await Course.countDocuments(filter);

    res.json({
      success: true,
      courses,
      pagination: {
        currentPage: parseInt(page),
        totalPages: Math.ceil(total / parseInt(limit)),
        totalCourses: total,
        hasNext: parseInt(page) < Math.ceil(total / parseInt(limit)),
        hasPrev: parseInt(page) > 1
      },
      filters: {
        categories: ['Computer Science', 'Mathematics', 'Physics', 'Chemistry', 'Biology', 'Engineering', 'Business', 'Literature', 'History', 'Art', 'Music', 'Language', 'Other'],
        difficulties: ['beginner', 'intermediate', 'advanced'],
        sortOptions: ['newest', 'popular', 'rating', 'name']
      }
    });
  } catch (error) {
    console.error('❌ Browse courses error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to browse courses'
    });
  }
});

// @desc    Get course statistics
// @route   GET /api/courses/stats
// @access  Private (Professor only)
router.get('/stats/overview', authenticateToken, requireRole(['professor']), async (req, res) => {
  try {
    const stats = await Course.aggregate([
      { $match: { professor: req.user._id, isActive: true } },
      {
        $group: {
          _id: null,
          totalCourses: { $sum: 1 },
          publishedCourses: {
            $sum: { $cond: [{ $eq: ['$isPublished', true] }, 1, 0] }
          },
          totalEnrollments: { $sum: '$enrollmentCount' },
          avgRating: { $avg: '$rating.average' }
        }
      }
    ]);

    const recentCourses = await Course.find({
      professor: req.user._id,
      isActive: true
    })
      .select('name enrollmentCount rating.average createdAt')
      .sort({ createdAt: -1 })
      .limit(5);

    res.json({
      success: true,
      stats: stats[0] || {
        totalCourses: 0,
        publishedCourses: 0,
        totalEnrollments: 0,
        avgRating: 0
      },
      recentCourses
    });
  } catch (error) {
    console.error('❌ Get course stats error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get course statistics'
    });
  }
});

module.exports = router;