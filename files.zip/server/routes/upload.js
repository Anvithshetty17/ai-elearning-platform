const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs').promises;
const { v2: cloudinary } = require('cloudinary');
const { authenticateToken } = require('../middleware/auth');

const router = express.Router();

// Configure Cloudinary
cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
});

// Configure multer for temporary file storage
const storage = multer.diskStorage({
  destination: async (req, file, cb) => {
    const uploadPath = path.join(__dirname, '..', 'uploads', 'temp');
    try {
      await fs.mkdir(uploadPath, { recursive: true });
      cb(null, uploadPath);
    } catch (error) {
      cb(error);
    }
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = `${Date.now()}-${Math.round(Math.random() * 1E9)}`;
    cb(null, `${file.fieldname}-${uniqueSuffix}${path.extname(file.originalname)}`);
  }
});

const fileFilter = (req, file, cb) => {
  // Allow images and documents
  const allowedTypes = [
    'image/jpeg',
    'image/png',
    'image/gif',
    'image/webp',
    'text/plain',
    'application/pdf',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
  ];
  
  if (allowedTypes.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(new Error('File type not allowed'), false);
  }
};

const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB
    files: 5
  }
});

// @desc    Upload avatar image
// @route   POST /api/upload/avatar
// @access  Private
router.post('/avatar', authenticateToken, upload.single('avatar'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: 'No file uploaded'
      });
    }

    // Upload to Cloudinary
    const result = await cloudinary.uploader.upload(req.file.path, {
      folder: 'ai-elearning/avatars',
      public_id: `avatar_${req.user._id}`,
      transformation: [
        { width: 300, height: 300, crop: 'fill', gravity: 'face' },
        { quality: 'auto', format: 'auto' }
      ]
    });

    // Update user avatar
    const User = require('../models/User');
    await User.findByIdAndUpdate(req.user._id, {
      avatar: {
        public_id: result.public_id,
        url: result.secure_url
      }
    });

    // Clean up temp file
    await fs.unlink(req.file.path).catch(console.error);

    console.log(`✅ Avatar uploaded for user: ${req.user.email}`);

    res.json({
      success: true,
      message: 'Avatar uploaded successfully',
      avatar: {
        public_id: result.public_id,
        url: result.secure_url
      }
    });
  } catch (error) {
    console.error('❌ Avatar upload error:', error);
    
    // Clean up temp file on error
    if (req.file) {
      await fs.unlink(req.file.path).catch(console.error);
    }

    res.status(500).json({
      success: false,
      message: 'Failed to upload avatar',
      error: process.env.NODE_ENV === 'development' ? error.message : 'Upload failed'
    });
  }
});

// @desc    Upload course thumbnail
// @route   POST /api/upload/course-thumbnail
// @access  Private (Professor only)
router.post('/course-thumbnail', authenticateToken, upload.single('thumbnail'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: 'No file uploaded'
      });
    }

    if (req.user.role !== 'professor') {
      return res.status(403).json({
        success: false,
        message: 'Only professors can upload course thumbnails'
      });
    }

    const { courseId } = req.body;
    if (!courseId) {
      return res.status(400).json({
        success: false,
        message: 'Course ID is required'
      });
    }

    // Verify course ownership
    const Course = require('../models/Course');
    const course = await Course.findOne({ _id: courseId, professor: req.user._id });
    if (!course) {
      return res.status(404).json({
        success: false,
        message: 'Course not found or unauthorized'
      });
    }

    // Upload to Cloudinary
    const result = await cloudinary.uploader.upload(req.file.path, {
      folder: 'ai-elearning/course-thumbnails',
      public_id: `course_${courseId}`,
      transformation: [
        { width: 800, height: 600, crop: 'fill' },
        { quality: 'auto', format: 'auto' }
      ]
    });

    // Update course thumbnail
    course.thumbnail = {
      public_id: result.public_id,
      url: result.secure_url
    };
    await course.save();

    // Clean up temp file
    await fs.unlink(req.file.path).catch(console.error);

    console.log(`✅ Course thumbnail uploaded: ${course.name}`);

    res.json({
      success: true,
      message: 'Course thumbnail uploaded successfully',
      thumbnail: {
        public_id: result.public_id,
        url: result.secure_url
      }
    });
  } catch (error) {
    console.error('❌ Course thumbnail upload error:', error);
    
    if (req.file) {
      await fs.unlink(req.file.path).catch(console.error);
    }

    res.status(500).json({
      success: false,
      message: 'Failed to upload course thumbnail'
    });
  }
});

// @desc    Delete uploaded file from Cloudinary
// @route   DELETE /api/upload/:public_id
// @access  Private
router.delete('/:public_id', authenticateToken, async (req, res) => {
  try {
    const { public_id } = req.params;
    
    // Delete from Cloudinary
    const result = await cloudinary.uploader.destroy(public_id);
    
    if (result.result === 'ok') {
      res.json({
        success: true,
        message: 'File deleted successfully'
      });
    } else {
      res.status(404).json({
        success: false,
        message: 'File not found'
      });
    }
  } catch (error) {
    console.error('❌ File delete error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to delete file'
    });
  }
});

module.exports = router;