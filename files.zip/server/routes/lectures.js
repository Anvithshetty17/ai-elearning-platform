const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs').promises;
const { body, validationResult, query } = require('express-validator');
const axios = require('axios');

const Lecture = require('../models/Lecture');
const Course = require('../models/Course');
const { authenticateToken, requireRole } = require('../middleware/auth');

const router = express.Router();

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: async (req, file, cb) => {
    const uploadPath = path.join(__dirname, '..', 'uploads', 'lectures');
    try {
      await fs.mkdir(uploadPath, { recursive: true });
      cb(null, uploadPath);
    } catch (error) {
      cb(error);
    }
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = `${Date.now()}-${Math.round(Math.random() * 1E9)}`;
    cb(null, `lecture-${uniqueSuffix}${path.extname(file.originalname)}`);
  }
});

const fileFilter = (req, file, cb) => {
  // Accept text files and documents
  const allowedTypes = [
    'text/plain',
    'text/markdown',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/pdf'
  ];
  
  if (allowedTypes.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(new Error('Only text, markdown, Word, and PDF files are allowed'), false);
  }
};

const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
    files: 1
  }
});

// @desc    Create new lecture
// @route   POST /api/lectures
// @access  Private (Professor only)
router.post('/', authenticateToken, requireRole(['professor']), upload.single('textFile'), [
  body('title')
    .trim()
    .isLength({ min: 3, max: 300 })
    .withMessage('Title must be between 3 and 300 characters'),
  body('courseId')
    .isMongoId()
    .withMessage('Valid course ID required'),
  body('description')
    .optional()
    .trim()
    .isLength({ max: 2000 })
    .withMessage('Description cannot exceed 2000 characters'),
  body('textContent')
    .optional()
    .trim()
    .isLength({ min: 10, max: 50000 })
    .withMessage('Text content must be between 10 and 50,000 characters'),
  body('language')
    .optional()
    .isIn(['en', 'es', 'fr', 'de', 'it', 'pt', 'ru', 'ja', 'ko', 'zh'])
    .withMessage('Unsupported language'),
  body('voiceSettings.speed')
    .optional()
    .isFloat({ min: 0.5, max: 2.0 })
    .withMessage('Voice speed must be between 0.5 and 2.0'),
  body('voiceSettings.voice')
    .optional()
    .isIn(['default', 'male', 'female', 'robotic'])
    .withMessage('Invalid voice type')
], async (req, res) => {
  let uploadedFilePath = null;
  
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      // Clean up uploaded file if validation fails
      if (req.file) {
        await fs.unlink(req.file.path).catch(console.error);
      }
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: errors.array()
      });
    }

    const { title, description, courseId, textContent, language, voiceSettings, videoSettings, tags } = req.body;
    
    // Verify course exists and belongs to professor
    const course = await Course.findOne({ _id: courseId, professor: req.user._id });
    if (!course) {
      if (req.file) {
        await fs.unlink(req.file.path).catch(console.error);
      }
      return res.status(404).json({
        success: false,
        message: 'Course not found or unauthorized'
      });
    }

    // Handle text content (either from file or direct input)
    let lectureText = textContent;
    
    if (req.file) {
      uploadedFilePath = req.file.path;
      try {
        const fileBuffer = await fs.readFile(req.file.path);
        
        // Handle different file types
        switch (req.file.mimetype) {
          case 'text/plain':
          case 'text/markdown':
            lectureText = fileBuffer.toString('utf8');
            break;
          case 'application/pdf':
            // For PDF files, you might want to use a PDF parser library
            // For now, we'll just return an error
            throw new Error('PDF parsing not implemented yet. Please use plain text files.');
          default:
            throw new Error('Unsupported file type');
        }
      } catch (fileError) {
        await fs.unlink(req.file.path).catch(console.error);
        return res.status(400).json({
          success: false,
          message: `File processing error: ${fileError.message}`
        });
      }
    }

    if (!lectureText || lectureText.trim().length < 10) {
      if (uploadedFilePath) {
        await fs.unlink(uploadedFilePath).catch(console.error);
      }
      return res.status(400).json({
        success: false,
        message: 'Lecture text content is required and must be at least 10 characters'
      });
    }

    // Create lecture
    const lecture = new Lecture({
      title: title.trim(),
      description: description?.trim(),
      professor: req.user._id,
      course: courseId,
      textContent: lectureText.trim(),
      language: language || 'en',
      voiceSettings: {
        speed: voiceSettings?.speed || 1.0,
        pitch: voiceSettings?.pitch || 1.0,
        voice: voiceSettings?.voice || 'default'
      },
      videoSettings: {
        quality: videoSettings?.quality || '720p',
        avatarType: videoSettings?.avatarType || 'static',
        backgroundType: videoSettings?.backgroundType || 'simple'
      },
      tags: tags || [],
      status: 'pending'
    });

    await lecture.save();

    // Add lecture to course
    await course.addLecture(lecture._id);

    // Clean up uploaded file after processing
    if (uploadedFilePath) {
      await fs.unlink(uploadedFilePath).catch(console.error);
    }

    // Trigger AI processing asynchronously
    try {
      const mlServiceResponse = await axios.post(
        `${process.env.ML_SERVICE_URL}/process-lecture`,
        {
          lectureId: lecture._id.toString(),
          textContent: lectureText,
          language: lecture.language,
          voiceSettings: lecture.voiceSettings,
          videoSettings: lecture.videoSettings
        },
        { timeout: 5000 }
      );
      
      if (mlServiceResponse.status === 200) {
        lecture.status = 'processing';
        await lecture.save();
        console.log(`✅ ML processing started for lecture: ${lecture.title}`);
      }
    } catch (mlError) {
      console.error('⚠️ ML service error (will retry later):', mlError.message);
      // Don't fail the request, just log the error
      // The lecture can be processed later
    }

    await lecture.populate('professor', 'name email avatar');
    await lecture.populate('course', 'name');

    console.log(`✅ Lecture created: ${lecture.title} by ${req.user.name}`);

    res.status(201).json({
      success: true,
      message: 'Lecture created successfully',
      lecture
    });
  } catch (error) {
    console.error('❌ Create lecture error:', error);
    
    // Clean up uploaded file on error
    if (uploadedFilePath) {
      await fs.unlink(uploadedFilePath).catch(console.error);
    }

    res.status(500).json({
      success: false,
      message: 'Failed to create lecture',
      error: process.env.NODE_ENV === 'development' ? error.message : 'Internal server error'
    });
  }
});

// @desc    Get lectures for a course
// @route   GET /api/lectures/course/:courseId
// @access  Private
router.get('/course/:courseId', authenticateToken, [
  query('page').optional().isInt({ min: 1 }).withMessage('Page must be a positive integer'),
  query('limit').optional().isInt({ min: 1, max: 50 }).withMessage('Limit must be between 1 and 50'),
  query('status').optional().isIn(['pending', 'processing', 'completed', 'failed', 'all'])
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: errors.array()
      });
    }

    const { courseId } = req.params;
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const status = req.query.status;
    
    // Verify access to course
    const course = await Course.findById(courseId);
    if (!course) {
      return res.status(404).json({
        success: false,
        message: 'Course not found'
      });
    }

    // Check if user has access (professor or enrolled student)
    const isProfessor = course.professor.equals(req.user._id);
    const isEnrolled = course.students.includes(req.user._id);
    
    if (!isProfessor && !isEnrolled) {
      return res.status(403).json({
        success: false,
        message: 'Access denied to this course'
      });
    }

    // Build query
    const query = { 
      course: courseId, 
      isActive: true 
    };

    // Filter by status if specified
    if (status && status !== 'all') {
      query.status = status;
    }

    // Students can only see completed, published lectures
    if (req.user.role === 'student' && !isProfessor) {
      query.status = 'completed';
      query.isPublished = true;
    }

    const lectures = await Lecture.find(query)
      .populate('professor', 'name email avatar')
      .populate('course', 'name')
      .select(isProfessor ? 
        // Professor sees all fields
        '-textContent -processingLogs' : 
        // Students see limited fields
        'title description videoUrl thumbnailUrl duration views status isPublished createdAt order'
      )
      .sort({ order: 1, createdAt: 1 })
      .limit(limit)
      .skip((page - 1) * limit);

    const total = await Lecture.countDocuments(query);

    res.json({
      success: true,
      lectures,
      pagination: {
        currentPage: page,
        totalPages: Math.ceil(total / limit),
        totalLectures: total,
        hasNext: page < Math.ceil(total / limit),
        hasPrev: page > 1
      }
    });
  } catch (error) {
    console.error('❌ Get lectures error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get lectures'
    });
  }
});

// @desc    Get single lecture
// @route   GET /api/lectures/:id
// @access  Private
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const lecture = await Lecture.findById(req.params.id)
      .populate('professor', 'name email avatar bio')
      .populate('course', 'name description professor');

    if (!lecture || !lecture.isActive) {
      return res.status(404).json({
        success: false,
        message: 'Lecture not found'
      });
    }

    // Check access permissions
    const course = await Course.findById(lecture.course._id);
    const isProfessor = course.professor.equals(req.user._id);
    const isEnrolled = course.students.includes(req.user._id);

    if (!isProfessor && !isEnrolled) {
      return res.status(403).json({
        success: false,
        message: 'Access denied to this lecture'
      });
    }

    // Students can only see completed, published lectures
    if (req.user.role === 'student' && !isProfessor) {
      if (lecture.status !== 'completed' || !lecture.isPublished) {
        return res.status(403).json({
          success: false,
          message: 'Lecture not available'
        });
      }
    }

    // Increment view count (async, don't wait)
    lecture.incrementViews().catch(console.error);

    // Filter sensitive data for students
    let responseData = lecture.toObject();
    if (req.user.role === 'student' && !isProfessor) {
      delete responseData.textContent;
      delete responseData.processingLogs;
      delete responseData.errorMessage;
      responseData.canDownload = lecture.status === 'completed';
    }

    res.json({
      success: true,
      lecture: responseData
    });
  } catch (error) {
    console.error('❌ Get lecture error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get lecture details'
    });
  }
});

// @desc    Update lecture
// @route   PUT /api/lectures/:id
// @access  Private (Professor only - own lectures)
router.put('/:id', authenticateToken, requireRole(['professor']), [
  body('title')
    .optional()
    .trim()
    .isLength({ min: 3, max: 300 })
    .withMessage('Title must be between 3 and 300 characters'),
  body('description')
    .optional()
    .trim()
    .isLength({ max: 2000 })
    .withMessage('Description cannot exceed 2000 characters'),
  body('order')
    .optional()
    .isInt({ min: 0 })
    .withMessage('Order must be a non-negative integer')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: errors.array()
      });
    }

    const lecture = await Lecture.findOne({
      _id: req.params.id,
      professor: req.user._id,
      isActive: true
    });

    if (!lecture) {
      return res.status(404).json({
        success: false,
        message: 'Lecture not found or unauthorized'
      });
    }

    const allowedUpdates = [
      'title', 'description', 'order', 'isPublished', 'tags'
    ];

    allowedUpdates.forEach(field => {
      if (req.body[field] !== undefined) {
        lecture[field] = req.body[field];
      }
    });

    await lecture.save();

    console.log(`✅ Lecture updated: ${lecture.title} by ${req.user.name}`);

    res.json({
      success: true,
      message: 'Lecture updated successfully',
      lecture
    });
  } catch (error) {
    console.error('❌ Update lecture error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update lecture'
    });
  }
});

// @desc    Delete lecture
// @route   DELETE /api/lectures/:id
// @access  Private (Professor only - own lectures)
router.delete('/:id', authenticateToken, requireRole(['professor']), async (req, res) => {
  try {
    const lecture = await Lecture.findOne({
      _id: req.params.id,
      professor: req.user._id,
      isActive: true
    });

    if (!lecture) {
      return res.status(404).json({
        success: false,
        message: 'Lecture not found or unauthorized'
      });
    }

    // Soft delete
    lecture.isActive = false;
    await lecture.save();

    // Remove from course
    const course = await Course.findById(lecture.course);
    if (course) {
      await course.removeLecture(lecture._id);
    }

    console.log(`✅ Lecture deleted: ${lecture.title} by ${req.user.name}`);

    res.json({
      success: true,
      message: 'Lecture deleted successfully'
    });
  } catch (error) {
    console.error('❌ Delete lecture error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to delete lecture'
    });
  }
});

// @desc    Regenerate video for a lecture
// @route   POST /api/lectures/:id/regenerate
// @access  Private (Professor only - own lectures)
router.post('/:id/regenerate', authenticateToken, requireRole(['professor']), async (req, res) => {
  try {
    const lecture = await Lecture.findOne({
      _id: req.params.id,
      professor: req.user._id,
      isActive: true
    });

    if (!lecture) {
      return res.status(404).json({
        success: false,
        message: 'Lecture not found or unauthorized'
      });
    }

    if (lecture.status === 'processing') {
      return res.status(400).json({
        success: false,
        message: 'Lecture is currently being processed'
      });
    }

    // Reset lecture for reprocessing
    lecture.status = 'pending';
    lecture.processingStage = 'text-analysis';
    lecture.processingProgress = 0;
    lecture.errorMessage = '';
    
    // Clear previous URLs
    lecture.audioUrl = { url: '', public_id: '' };
    lecture.videoUrl = { url: '', public_id: '' };
    lecture.thumbnailUrl = { url: '', public_id: '' };

    await lecture.save();

    // Trigger AI processing
    try {
      const mlServiceResponse = await axios.post(
        `${process.env.ML_SERVICE_URL}/process-lecture`,
        {
          lectureId: lecture._id.toString(),
          textContent: lecture.textContent,
          language: lecture.language,
          voiceSettings: lecture.voiceSettings,
          videoSettings: lecture.videoSettings
        },
        { timeout: 5000 }
      );

      if (mlServiceResponse.status === 200) {
        lecture.status = 'processing';
        await lecture.save();
        console.log(`✅ Lecture regeneration started: ${lecture.title}`);
      }
    } catch (mlError) {
      console.error('❌ ML service error:', mlError.message);
      lecture.status = 'failed';
      lecture.errorMessage = 'Failed to connect to AI processing service';
      await lecture.save();
      
      return res.status(500).json({
        success: false,
        message: 'Failed to start processing. Please try again later.'
      });
    }

    res.json({
      success: true,
      message: 'Lecture regeneration started successfully',
      lecture: {
        id: lecture._id,
        status: lecture.status,
        processingStage: lecture.processingStage,
        processingProgress: lecture.processingProgress
      }
    });
  } catch (error) {
    console.error('❌ Regenerate lecture error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to regenerate lecture'
    });
  }
});

// @desc    Update lecture status (called by ML service)
// @route   PATCH /api/lectures/:id/status
// @access  Internal (ML Service)
router.patch('/:id/status', [
  body('status')
    .isIn(['pending', 'processing', 'completed', 'failed'])
    .withMessage('Invalid status'),
  body('stage')
    .optional()
    .isIn(['text-analysis', 'tts-conversion', 'video-generation', 'upload', 'completed']),
  body('progress')
    .optional()
    .isInt({ min: 0, max: 100 })
    .withMessage('Progress must be between 0 and 100')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: errors.array()
      });
    }

    const { status, stage, progress, videoUrl, audioUrl, thumbnailUrl, transcript, duration, errorMessage } = req.body;
    
    const lecture = await Lecture.findById(req.params.id);
    if (!lecture) {
      return res.status(404).json({
        success: false,
        message: 'Lecture not found'
      });
    }

    // Update lecture fields
    lecture.status = status;
    if (stage) lecture.processingStage = stage;
    if (progress !== undefined) lecture.processingProgress = progress;
    if (duration) lecture.duration = duration;
    if (transcript) lecture.transcript = transcript;
    if (errorMessage) lecture.errorMessage = errorMessage;

    // Update media URLs
    if (videoUrl) {
      lecture.videoUrl = typeof videoUrl === 'string' ? 
        { url: videoUrl, public_id: '' } : videoUrl;
    }
    if (audioUrl) {
      lecture.audioUrl = typeof audioUrl === 'string' ? 
        { url: audioUrl, public_id: '' } : audioUrl;
    }
    if (thumbnailUrl) {
      lecture.thumbnailUrl = typeof thumbnailUrl === 'string' ? 
        { url: thumbnailUrl, public_id: '' } : thumbnailUrl;
    }

    // Add processing log
    lecture.processingLogs.push({
      stage: stage || lecture.processingStage,
      message: status === 'failed' ? errorMessage : `Status updated to ${status}`,
      level: status === 'failed' ? 'error' : 'info'
    });

    await lecture.save();

    console.log(`✅ Lecture status updated: ${lecture.title} - ${status}`);

    res.json({
      success: true,
      message: 'Lecture status updated successfully',
      lecture: {
        id: lecture._id,
        status: lecture.status,
        processingStage: lecture.processingStage,
        processingProgress: lecture.processingProgress
      }
    });
  } catch (error) {
    console.error('❌ Update lecture status error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update lecture status'
    });
  }
});

// @desc    Get lecture processing status
// @route   GET /api/lectures/:id/status
// @access  Private (Professor only - own lectures)
router.get('/:id/status', authenticateToken, requireRole(['professor']), async (req, res) => {
  try {
    const lecture = await Lecture.findOne({
      _id: req.params.id,
      professor: req.user._id,
      isActive: true
    }).select('status processingStage processingProgress errorMessage processingLogs');

    if (!lecture) {
      return res.status(404).json({
        success: false,
        message: 'Lecture not found or unauthorized'
      });
    }

    res.json({
      success: true,
      status: {
        current: lecture.status,
        stage: lecture.processingStage,
        progress: lecture.processingProgress,
        errorMessage: lecture.errorMessage,
        canRetry: lecture.status === 'failed' && lecture.retryCount < lecture.maxRetries,
        logs: lecture.processingLogs.slice(-5) // Last 5 logs
      }
    });
  } catch (error) {
    console.error('❌ Get lecture status error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get lecture status'
    });
  }
});

// @desc    Add comment to lecture
// @route   POST /api/lectures/:id/comments
// @access  Private
router.post('/:id/comments', authenticateToken, [
  body('content')
    .trim()
    .isLength({ min: 1, max: 1000 })
    .withMessage('Comment must be between 1 and 1000 characters')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: errors.array()
      });
    }

    const { content } = req.body;
    const lecture = await Lecture.findById(req.params.id);

    if (!lecture || !lecture.isActive) {
      return res.status(404).json({
        success: false,
        message: 'Lecture not found'
      });
    }

    // Check if user has access to the lecture
    const course = await Course.findById(lecture.course);
    const hasAccess = course.professor.equals(req.user._id) || 
                     course.students.includes(req.user._id);

    if (!hasAccess) {
      return res.status(403).json({
        success: false,
        message: 'Access denied'
      });
    }

    await lecture.addComment(req.user._id, content);
    await lecture.populate('comments.user', 'name avatar');

    const newComment = lecture.comments[lecture.comments.length - 1];

    res.status(201).json({
      success: true,
      message: 'Comment added successfully',
      comment: newComment
    });
  } catch (error) {
    console.error('❌ Add comment error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to add comment'
    });
  }
});

module.exports = router;