import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { 
  Menu, 
  X, 
  User, 
  BookOpen, 
  Upload, 
  PlusCircle, 
  LogOut,
  Home,
  Search,
  Settings
} from 'lucide-react';
import './Navbar.css';

const Navbar = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/');
    setIsMenuOpen(false);
  };

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const closeMenu = () => {
    setIsMenuOpen(false);
  };

  const isActive = (path) => {
    return location.pathname === path;
  };

  return (
    <nav className="navbar">
      <div className="nav-container">
        <Link to="/" className="nav-logo" onClick={closeMenu}>
          <BookOpen size={28} />
          <span className="logo-text">AI EduPlatform</span>
        </Link>

        <div className={`nav-menu ${isMenuOpen ? 'active' : ''}`}>
          {user ? (
            <>
              <Link 
                to="/dashboard" 
                className={`nav-link ${isActive('/dashboard') ? 'active' : ''}`}
                onClick={closeMenu}
              >
                <Home size={18} />
                <span>Dashboard</span>
              </Link>
              
              <Link 
                to="/courses" 
                className={`nav-link ${isActive('/courses') ? 'active' : ''}`}
                onClick={closeMenu}
              >
                <BookOpen size={18} />
                <span>My Courses</span>
              </Link>

              <Link 
                to="/browse" 
                className={`nav-link ${isActive('/browse') ? 'active' : ''}`}
                onClick={closeMenu}
              >
                <Search size={18} />
                <span>Browse</span>
              </Link>

              {user.role === 'professor' && (
                <>
                  <Link 
                    to="/create-course" 
                    className={`nav-link ${isActive('/create-course') ? 'active' : ''}`}
                    onClick={closeMenu}
                  >
                    <PlusCircle size={18} />
                    <span>Create Course</span>
                  </Link>
                  <Link 
                    to="/upload-lecture" 
                    className={`nav-link ${isActive('/upload-lecture') ? 'active' : ''}`}
                    onClick={closeMenu}
                  >
                    <Upload size={18} />
                    <span>Upload Lecture</span>
                  </Link>
                </>
              )}

              <div className="nav-divider"></div>

              <div className="nav-user">
                <div className="user-info">
                  <div className="user-avatar">
                    {user.avatar?.url ? (
                      <img src={user.avatar.url} alt={user.name} />
                    ) : (
                      <User size={18} />
                    )}
                  </div>
                  <div className="user-details">
                    <span className="user-name">{user.name}</span>
                    <span className="user-role">{user.role}</span>
                  </div>
                </div>
                
                <div className="user-actions">
                  <Link 
                    to="/profile" 
                    className="user-action-btn"
                    onClick={closeMenu}
                  >
                    <Settings size={16} />
                  </Link>
                  <button onClick={handleLogout} className="user-action-btn logout">
                    <LogOut size={16} />
                  </button>
                </div>
              </div>
            </>
          ) : (
            <>
              <Link 
                to="/browse" 
                className={`nav-link ${isActive('/browse') ? 'active' : ''}`}
                onClick={closeMenu}
              >
                <Search size={18} />
                <span>Browse Courses</span>
              </Link>
              <Link 
                to="/login" 
                className={`nav-link ${isActive('/login') ? 'active' : ''}`}
                onClick={closeMenu}
              >
                Login
              </Link>
              <Link 
                to="/register" 
                className={`nav-link nav-btn ${isActive('/register') ? 'active' : ''}`}
                onClick={closeMenu}
              >
                Get Started
              </Link>
            </>
          )}
        </div>

        <div className="nav-toggle" onClick={toggleMenu}>
          {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;