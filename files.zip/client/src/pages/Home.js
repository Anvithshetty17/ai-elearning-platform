import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { 
  Play, 
  BookOpen, 
  Users, 
  Award, 
  ArrowRight, 
  CheckCircle,
  Zap,
  Globe,
  Star
} from 'lucide-react';
import './Home.css';

const Home = () => {
  const { user } = useAuth();

  const features = [
    {
      icon: <Zap className="feature-icon" />,
      title: "AI-Generated Videos",
      description: "Transform text lectures into engaging AI-narrated videos with avatars and visuals"
    },
    {
      icon: <BookOpen className="feature-icon" />,
      title: "Smart Course Creation",
      description: "Create comprehensive courses with AI-powered content generation and organization"
    },
    {
      icon: <Users className="feature-icon" />,
      title: "Interactive Learning",
      description: "Engage students with interactive content, discussions, and progress tracking"
    },
    {
      icon: <Globe className="feature-icon" />,
      title: "Multi-Language Support",
      description: "Generate content in multiple languages with natural voice synthesis"
    }
  ];

  const stats = [
    { number: "10,000+", label: "Students Learning" },
    { number: "500+", label: "AI-Generated Lectures" },
    { number: "100+", label: "Expert Professors" },
    { number: "50+", label: "Course Categories" }
  ];

  const testimonials = [
    {
      name: "Dr. Sarah Johnson",
      role: "Computer Science Professor",
      content: "This platform revolutionized how I create and deliver lectures. The AI video generation saves hours of work!",
      rating: 5
    },
    {
      name: "Michael Chen",
      role: "Engineering Student",
      content: "Learning through AI-generated videos is incredibly engaging. The content is clear and easy to follow.",
      rating: 5
    },
    {
      name: "Prof. Emma Davis",
      role: "Mathematics Professor",
      content: "The multi-language support helped me reach students globally. Amazing technology!",
      rating: 5
    }
  ];

  return (
    <div className="home">
      {/* Hero Section */}
      <section className="hero">
        <div className="hero-content">
          <div className="hero-text">
            <h1 className="hero-title">
              Transform Education with
              <span className="gradient-text"> AI-Powered Learning</span>
            </h1>
            <p className="hero-description">
              Create engaging video lectures from text using cutting-edge AI technology. 
              Revolutionize online education with automated content generation, 
              multi-language support, and interactive learning experiences.
            </p>
            <div className="hero-actions">
              {user ? (
                <Link to="/dashboard" className="btn btn-primary btn-large">
                  <Play size={20} />
                  Go to Dashboard
                </Link>
              ) : (
                <>
                  <Link to="/register" className="btn btn-primary btn-large">
                    Get Started Free
                    <ArrowRight size={20} />
                  </Link>
                  <Link to="/browse" className="btn btn-secondary btn-large">
                    <BookOpen size={20} />
                    Browse Courses
                  </Link>
                </>
              )}
            </div>
            <div className="hero-benefits">
              <div className="benefit">
                <CheckCircle size={16} />
                <span>No credit card required</span>
              </div>
              <div className="benefit">
                <CheckCircle size={16} />
                <span>Free tier available</span>
              </div>
              <div className="benefit">
                <CheckCircle size={16} />
                <span>Setup in minutes</span>
              </div>
            </div>
          </div>
          <div className="hero-visual">
            <div className="hero-video-placeholder">
              <div className="video-icon">
                <Play size={60} />
              </div>
              <div className="video-controls">
                <div className="control active"></div>
                <div className="control"></div>
                <div className="control"></div>
              </div>
            </div>
            <div className="floating-elements">
              <div className="floating-element element-1">
                <BookOpen size={24} />
              </div>
              <div className="floating-element element-2">
                <Users size={24} />
              </div>
              <div className="floating-element element-3">
                <Award size={24} />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="stats">
        <div className="container">
          <div className="stats-grid">
            {stats.map((stat, index) => (
              <div key={index} className="stat-item">
                <div className="stat-number">{stat.number}</div>
                <div className="stat-label">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="features">
        <div className="container">
          <div className="section-header">
            <h2 className="section-title">Powerful Features</h2>
            <p className="section-description">
              Everything you need to create, manage, and deliver world-class online education
            </p>
          </div>
          <div className="features-grid">
            {features.map((feature, index) => (
              <div key={index} className="feature-card">
                <div className="feature-icon-wrapper">
                  {feature.icon}
                </div>
                <h3 className="feature-title">{feature.title}</h3>
                <p className="feature-description">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How it Works Section */}
      <section className="how-it-works">
        <div className="container">
          <div className="section-header">
            <h2 className="section-title">How It Works</h2>
            <p className="section-description">
              Create professional video lectures in just a few simple steps
            </p>
          </div>
          <div className="steps-grid">
            <div className="step">
              <div className="step-number">1</div>
              <div className="step-content">
                <h3>Write Your Content</h3>
                <p>Simply type or upload your lecture text content</p>
              </div>
            </div>
            <div className="step">
              <div className="step-number">2</div>
              <div className="step-content">
                <h3>AI Processing</h3>
                <p>Our AI converts text to speech and generates engaging videos</p>
              </div>
            </div>
            <div className="step">
              <div className="step-number">3</div>
              <div className="step-content">
                <h3>Share & Teach</h3>
                <p>Publish your courses and start teaching students worldwide</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="testimonials">
        <div className="container">
          <div className="section-header">
            <h2 className="section-title">What Educators Say</h2>
            <p className="section-description">
              Join thousands of educators transforming their teaching experience
            </p>
          </div>
          <div className="testimonials-grid">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="testimonial-card">
                <div className="testimonial-rating">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} size={16} fill="currentColor" />
                  ))}
                </div>
                <p className="testimonial-content">"{testimonial.content}"</p>
                <div className="testimonial-author">
                  <div className="author-info">
                    <div className="author-name">{testimonial.name}</div>
                    <div className="author-role">{testimonial.role}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="cta">
        <div className="container">
          <div className="cta-content">
            <h2 className="cta-title">Ready to Transform Your Teaching?</h2>
            <p className="cta-description">
              Join thousands of educators creating amazing content with AI
            </p>
            <div className="cta-actions">
              {user ? (
                <Link to="/dashboard" className="btn btn-primary btn-large">
                  Go to Dashboard
                  <ArrowRight size={20} />
                </Link>
              ) : (
                <>
                  <Link to="/register" className="btn btn-primary btn-large">
                    Start Creating Today
                    <ArrowRight size={20} />
                  </Link>
                  <Link to="/browse" className="btn btn-secondary btn-large">
                    Explore Courses
                  </Link>
                </>
              )}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;