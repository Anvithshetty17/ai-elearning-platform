import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import axios from 'axios';
import LoadingSpinner from '../components/LoadingSpinner';
import {
  BookOpen,
  Users,
  Play,
  PlusCircle,
  Upload,
  TrendingUp,
  Clock,
  Award,
  BarChart3
} from 'lucide-react';
import './Dashboard.css';

const Dashboard = () => {
  const { user } = useAuth();
  const [stats, setStats] = useState(null);
  const [recentCourses, setRecentCourses] = useState([]);
  const [recentLectures, setRecentLectures] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, [user]);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      
      if (user.role === 'professor') {
        // Fetch professor stats
        const [statsResponse, coursesResponse] = await Promise.all([
          axios.get('/courses/stats/overview'),
          axios.get('/courses?limit=5')
        ]);
        
        setStats(statsResponse.data.stats);
        setRecentCourses(coursesResponse.data.courses);
      } else {
        // Fetch student data
        const coursesResponse = await axios.get('/courses?status=enrolled&limit=5');
        setRecentCourses(coursesResponse.data.courses);
      }
    } catch (error) {
      console.error('Failed to fetch dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <LoadingSpinner size="large" message="Loading dashboard..." />;
  }

  return (
    <div className="dashboard">
      <div className="dashboard-container">
        {/* Header */}
        <div className="dashboard-header">
          <div className="header-content">
            <h1 className="dashboard-title">
              Welcome back, {user.name}! 👋
            </h1>
            <p className="dashboard-subtitle">
              {user.role === 'professor' 
                ? "Ready to inspire minds with AI-powered education?"
                : "Continue your learning journey"
              }
            </p>
          </div>
          <div className="header-actions">
            {user.role === 'professor' ? (
              <>
                <Link to="/create-course" className="btn btn-secondary">
                  <PlusCircle size={18} />
                  Create Course
                </Link>
                <Link to="/upload-lecture" className="btn btn-primary">
                  <Upload size={18} />
                  Upload Lecture
                </Link>
              </>
            ) : (
              <Link to="/browse" className="btn btn-primary">
                <BookOpen size={18} />
                Browse Courses
              </Link>
            )}
          </div>
        </div>

        {/* Stats Grid (Professor only) */}
        {user.role === 'professor' && stats && (
          <div className="stats-grid">
            <div className="stat-card">
              <div className="stat-icon">
                <BookOpen size={24} />
              </div>
              <div className="stat-content">
                <div className="stat-number">{stats.totalCourses || 0}</div>
                <div className="stat-label">Total Courses</div>
              </div>
            </div>
            <div className="stat-card">
              <div className="stat-icon">
                <Users size={24} />
              </div>
              <div className="stat-content">
                <div className="stat-number">{stats.totalEnrollments || 0}</div>
                <div className="stat-label">Total Students</div>
              </div>
            </div>
            <div className="stat-card">
              <div className="stat-icon">
                <Play size={24} />
              </div>
              <div className="stat-content">
                <div className="stat-number">{stats.publishedCourses || 0}</div>
                <div className="stat-label">Published</div>
              </div>
            </div>
            <div className="stat-card">
              <div className="stat-icon">
                <Award size={24} />
              </div>
              <div className="stat-content">
                <div className="stat-number">{stats.avgRating ? stats.avgRating.toFixed(1) : '0.0'}</div>
                <div className="stat-label">Avg Rating</div>
              </div>
            </div>
          </div>
        )}

        {/* Main Content */}
        <div className="dashboard-grid">
          {/* Recent/My Courses */}
          <div className="dashboard-card">
            <div className="card-header">
              <h3 className="card-title">
                {user.role === 'professor' ? 'Recent Courses' : 'My Courses'}
              </h3>
              <Link to="/courses" className="card-action">
                View All
              </Link>
            </div>
            <div className="card-content">
              {recentCourses.length > 0 ? (
                <div className="courses-list">
                  {recentCourses.slice(0, 4).map((course) => (
                    <Link 
                      key={course._id} 
                      to={`/courses/${course._id}`}
                      className="course-item"
                    >
                      <div className="course-thumbnail">
                        {course.thumbnail?.url ? (
                          <img src={course.thumbnail.url} alt={course.name} />
                        ) : (
                          <div className="thumbnail-placeholder">
                            <BookOpen size={24} />
                          </div>
                        )}
                      </div>
                      <div className="course-info">
                        <h4 className="course-name">{course.name}</h4>
                        <p className="course-meta">
                          {course.lectureCount || 0} lectures • {course.enrollmentCount || 0} students
                        </p>
                        <div className="course-progress">
                          <div className="progress-bar">
                            <div 
                              className="progress-fill" 
                              style={{ width: '60%' }}
                            ></div>
                          </div>
                          <span className="progress-text">60% complete</span>
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              ) : (
                <div className="empty-state">
                  <BookOpen size={48} />
                  <h4>No courses yet</h4>
                  <p>
                    {user.role === 'professor' 
                      ? "Start by creating your first course!"
                      : "Explore our course catalog to get started"
                    }
                  </p>
                  <Link 
                    to={user.role === 'professor' ? '/create-course' : '/browse'} 
                    className="btn btn-primary"
                  >
                    {user.role === 'professor' ? 'Create Course' : 'Browse Courses'}
                  </Link>
                </div>
              )}
            </div>
          </div>

          {/* Quick Actions */}
          <div className="dashboard-card">
            <div className="card-header">
              <h3 className="card-title">Quick Actions</h3>
            </div>
            <div className="card-content">
              <div className="quick-actions">
                {user.role === 'professor' ? (
                  <>
                    <Link to="/create-course" className="quick-action">
                      <div className="action-icon">
                        <PlusCircle size={20} />
                      </div>
                      <div className="action-content">
                        <h4>Create New Course</h4>
                        <p>Start building your next course</p>
                      </div>
                    </Link>
                    <Link to="/upload-lecture" className="quick-action">
                      <div className="action-icon">
                        <Upload size={20} />
                      </div>
                      <div className="action-content">
                        <h4>Upload Lecture</h4>
                        <p>Add content to existing courses</p>
                      </div>
                    </Link>
                    <Link to="/courses" className="quick-action">
                      <div className="action-icon">
                        <BarChart3 size={20} />
                      </div>
                      <div className="action-content">
                        <h4>Course Analytics</h4>
                        <p>View performance metrics</p>
                      </div>
                    </Link>
                  </>
                ) : (
                  <>
                    <Link to="/browse" className="quick-action">
                      <div className="action-icon">
                        <BookOpen size={20} />
                      </div>
                      <div className="action-content">
                        <h4>Browse Courses</h4>
                        <p>Discover new learning opportunities</p>
                      </div>
                    </Link>
                    <Link to="/courses" className="quick-action">
                      <div className="action-icon">
                        <Play size={20} />
                      </div>
                      <div className="action-content">
                        <h4>Continue Learning</h4>
                        <p>Resume where you left off</p>
                      </div>
                    </Link>
                    <Link to="/profile" className="quick-action">
                      <div className="action-icon">
                        <Award size={20} />
                      </div>
                      <div className="action-content">
                        <h4>My Achievements</h4>
                        <p>View certificates and progress</p>
                      </div>
                    </Link>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* Recent Activity */}
          <div className="dashboard-card span-2">
            <div className="card-header">
              <h3 className="card-title">Recent Activity</h3>
            </div>
            <div className="card-content">
              <div className="activity-list">
                <div className="activity-item">
                  <div className="activity-icon">
                    <BookOpen size={16} />
                  </div>
                  <div className="activity-content">
                    <p><strong>Course Created:</strong> "Introduction to AI"</p>
                    <span className="activity-time">2 hours ago</span>
                  </div>
                </div>
                <div className="activity-item">
                  <div className="activity-icon">
                    <Upload size={16} />
                  </div>
                  <div className="activity-content">
                    <p><strong>Lecture Uploaded:</strong> "Machine Learning Basics"</p>
                    <span className="activity-time">1 day ago</span>
                  </div>
                </div>
                <div className="activity-item">
                  <div className="activity-icon">
                    <Users size={16} />
                  </div>
                  <div className="activity-content">
                    <p><strong>New Enrollment:</strong> 5 students joined your course</p>
                    <span className="activity-time">2 days ago</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;