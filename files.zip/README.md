# 🎓 AI-Generated E-Learning Platform

A revolutionary e-learning platform that converts text lectures into AI-generated videos with narration and avatars.

## ✨ Features

- **Text-to-Video Conversion**: Upload lecture text and generate AI narrated videos
- **User Roles**: Separate dashboards for professors and students
- **Cloud Storage**: Videos hosted on Cloudinary for reliable streaming
- **Transcript Generation**: Automatic caption generation
- **Course Management**: Organize lectures into structured courses
- **Responsive Design**: Works seamlessly on desktop and mobile devices

## 🛠️ Tech Stack

- **Frontend**: React.js 18, React Router, Context API
- **Backend**: Node.js, Express.js, MongoDB, Mongoose
- **ML Services**: Python 3.8+, Flask, gTTS, MoviePy, OpenCV
- **Authentication**: JWT-based authentication system
- **Storage**: Cloudinary for video and media storage
- **Database**: MongoDB Atlas or local MongoDB

## 📁 Project Structure

```
ai-elearning-platform/
├── client/                 # React Frontend
│   ├── public/            # Static assets
│   ├── src/               # Source code
│   │   ├── components/    # Reusable components
│   │   ├── pages/         # Page components
│   │   ├── contexts/      # React contexts
│   │   ├── utils/         # Utility functions
│   │   └── styles/        # CSS files
│   └── package.json
├── server/                # Node.js Backend
│   ├── models/           # MongoDB models
│   ├── routes/           # API routes
│   ├── middleware/       # Custom middleware
│   ├── config/           # Configuration files
│   ├── uploads/          # Temporary uploads
│   └── package.json
├── ml-services/          # Python ML Services
│   ├── services/         # ML processing services
│   ├── models/           # AI models
│   ├── temp/             # Temporary files
│   ├── app.py            # Flask application
│   └── requirements.txt
├── database/             # Database schemas
├── docs/                 # Documentation
└── package.json          # Root package.json
```

## 🚀 Installation & Setup

### Prerequisites
- Node.js (v16.0 or higher)
- Python (3.8 or higher)
- MongoDB (local or Atlas)
- Git

### 1. Clone Repository
```bash
git clone https://github.com/Anvithshetty17/ai-elearning-platform.git
cd ai-elearning-platform
```

### 2. Install Dependencies
```bash
npm run install-all
```

### 3. Environment Configuration

Create `.env` files in both `server/` and `ml-services/` directories:

**server/.env**
```env
NODE_ENV=development
PORT=5000
MONGODB_URI=mongodb://localhost:27017/ai-elearning
JWT_SECRET=your_super_secret_jwt_key_change_in_production
JWT_EXPIRE=7d

# Cloudinary Configuration
CLOUDINARY_CLOUD_NAME=your_cloud_name
CLOUDINARY_API_KEY=your_api_key
CLOUDINARY_API_SECRET=your_api_secret

# ML Service
ML_SERVICE_URL=http://localhost:5001

# Email Configuration (Optional)
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USER=your-email@gmail.com
EMAIL_PASS=your-app-password
```

**ml-services/.env**
```env
FLASK_ENV=development
FLASK_PORT=5001
UPLOAD_FOLDER=./temp
MAX_FILE_SIZE=50MB
TTS_ENGINE=gtts
VIDEO_QUALITY=720p
```

### 4. Database Setup

Make sure MongoDB is running on your system or use MongoDB Atlas cloud service.

### 5. Start Development Servers
```bash
npm run dev
```

This will start:
- **React Frontend**: http://localhost:3000
- **Express Backend**: http://localhost:5000
- **Python ML Services**: http://localhost:5001

## 🎯 Usage Guide

### For Professors
1. **Register** as a professor
2. **Create Course** from the dashboard
3. **Upload Lecture Text** - paste or upload text files
4. **AI Processing** - system automatically generates video
5. **Publish** - make videos available to students

### For Students
1. **Register** as a student
2. **Browse Courses** - find available courses
3. **Enroll** in courses of interest
4. **Watch Videos** - access AI-generated lectures
5. **View Transcripts** - read along with videos

## 📚 API Documentation

### Authentication Endpoints
```
POST /api/auth/register    # Register new user
POST /api/auth/login       # User login
GET  /api/auth/me          # Get current user
```

### Course Endpoints
```
GET    /api/courses        # Get user's courses
POST   /api/courses        # Create new course (Professor)
GET    /api/courses/:id    # Get course details
PUT    /api/courses/:id    # Update course (Professor)
POST   /api/courses/:id/enroll  # Enroll in course (Student)
```

### Lecture Endpoints
```
GET    /api/lectures/course/:courseId  # Get course lectures
POST   /api/lectures                   # Create lecture (Professor)
GET    /api/lectures/:id               # Get lecture details
POST   /api/lectures/:id/regenerate    # Regenerate video
```

### ML Service Endpoints
```
POST   /tts                # Convert text to speech
POST   /generate-video     # Generate video from audio
POST   /transcript         # Generate transcript
```

## 🧪 Development

### Frontend Development
```bash
cd client
npm start
```

### Backend Development
```bash
cd server
npm run dev
```

### ML Services Development
```bash
cd ml-services
python app.py
```

### Running Tests
```bash
npm test
```

## 🔧 Configuration Options

### Video Generation Settings
- **TTS Engine**: Google TTS (gTTS) or pyttsx3
- **Video Quality**: 720p, 1080p
- **Avatar Options**: Static image or animated avatar
- **Voice Settings**: Speed, pitch, language

### Storage Options
- **Local Storage**: For development
- **Cloudinary**: For production (recommended)
- **AWS S3**: Alternative cloud storage

## 📱 Mobile Support

The platform is fully responsive and optimized for:
- Desktop browsers
- Tablet devices
- Mobile phones (iOS/Android)

## 🚢 Deployment

### Frontend (Vercel/Netlify)
```bash
cd client
npm run build
# Deploy the build folder
```

### Backend (Railway/Heroku)
```bash
cd server
# Configure environment variables
# Deploy to your chosen platform
```

### ML Services (Railway/Heroku)
```bash
cd ml-services
# Configure environment variables
# Deploy Python Flask application
```

## 🛡️ Security Features

- JWT-based authentication
- Password hashing with bcrypt
- Input validation and sanitization
- Role-based access control
- CORS protection
- Helmet.js security headers

## 🔄 Future Enhancements

- [ ] Real-time notifications
- [ ] Advanced analytics dashboard
- [ ] Mobile application (React Native)
- [ ] Multi-language support
- [ ] AI quiz generation
- [ ] Student progress tracking
- [ ] Certificate generation
- [ ] Video chapters and bookmarks
- [ ] Live streaming capabilities
- [ ] Integration with LMS platforms

## 📊 Performance

- Lazy loading for video content
- Caching for frequently accessed data
- Optimized database queries
- CDN integration for global delivery
- Progressive video loading

## 🤝 Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 👨‍💻 Author

**Anvith Shetty**
- GitHub: [@Anvithshetty17](https://github.com/Anvithshetty17)
- Email: anvithshetty17@gmail.com

## 🙏 Acknowledgments

- OpenAI for AI technology inspiration
- React team for the amazing framework
- MongoDB for the flexible database
- All contributors and users

## 📞 Support

For support and questions:
- Create an issue in the GitHub repository
- Email: anvithshetty17@gmail.com
- Documentation: Check the `/docs` folder

---

**Built with ❤️ for the future of education**